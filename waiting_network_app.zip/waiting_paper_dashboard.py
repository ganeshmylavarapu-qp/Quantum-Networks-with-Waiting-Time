"""Paper-only dashboard, using the manuscript generation model and styles."""
import io
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import streamlit as st

ORANGE, BLUE, PURPLE, CORAL = '#e69f00', '#4c78a8', '#8172b2', '#e76f51'

@st.cache_data(show_spinner=False)
def profiles(topology, n, max_exact, samples, seed):
    # Import-free profile generation; only five-node examples require exact orders.
    import itertools, random
    if topology == 'chain':
        paths = [(i,j,list(range(i,j+1))) for i in range(n) for j in range(i+1,n)]
    else:
        paths = [(0,i,[0,i]) for i in range(1,n)] + [(i,j,[i,0,j]) for i in range(1,n) for j in range(i+1,n)]
    direct = [x for x in paths if len(x[2])==2]
    conflict = [x for x in paths if len(x[2])>2]
    if topology=='star':
        orders=[conflict]
    elif len(conflict)<=8 and __import__('math').factorial(len(conflict))<=max_exact:
        orders=itertools.permutations(conflict)
    else:
        rng=random.Random(seed); orders=[conflict, list(reversed(conflict))]
        for _ in range(samples):
            order=conflict.copy();rng.shuffle(order);orders.append(order)
    all_links=[];all_ri=[];all_mx=[]
    for order in orders:
        waits={};links=[];ri=[];mx=[]
        for _,_,p in direct+list(order):
            k=len(p)-1;contrib={r:waits.get(r,0) for r in p[1:-1]}
            for r in contrib:waits[r]=contrib[r]+1
            segments=k;last=0;exposure=0
            for t in sorted(set(contrib.values())):
                exposure+=segments*(t-last)
                segments-=sum(v==t for v in contrib.values());last=t
            links.append(k);ri.append(exposure);mx.append(k*max(contrib.values(),default=0))
        # Canonical path order allows uniform vector evaluation across schedules.
        pairs=[(x[0],x[1]) for x in direct+list(order)]
        ix=np.argsort([u*n+v for u,v in pairs])
        all_links.append(np.array(links)[ix]);all_ri.append(np.array(ri)[ix]);all_mx.append(np.array(mx)[ix])
    return np.array(all_links),np.array(all_ri),np.array(all_mx)

def evaluate(prof, model, distances, deltas, modes, policy, T, alpha, d1, d2, rho, mem, fiber):
    """Reuse schedule decay at equal waiting intervals; evaluate grids in batches."""
    links,ri,mx=prof
    distances,deltas,modes=np.broadcast_arrays(np.asarray(distances,dtype=float),np.asarray(deltas,dtype=float),np.asarray(modes,dtype=float))
    shape=distances.shape
    ds,dt,ms=distances.ravel(),deltas.ravel(),modes.ravel()
    path_links=links[0].astype(float)
    n=int((1+np.sqrt(1+8*len(path_links)))/2)
    hi=np.empty(len(ds));lo=np.empty(len(ds))
    for interval in np.unique(dt):
        positions=np.flatnonzero(dt==interval)
        # Memory decay across schedules depends on delta_t, not distance or m.
        ref_decay=np.exp(-mx*interval/T)
        chosen_decay=ref_decay if policy=='Maximum waiting' else np.exp(-ri*interval/T)
        for offset in range(0,len(positions),256):
            ix=positions[offset:offset+256]
            t0=ds[ix]*1000/(3e8/fiber)*1000
            single=np.clip(d1*d1*rho*rho*10**(-alpha*ds[ix]/10),0,1)
            with np.errstate(divide='ignore',invalid='ignore'):
                pe=-np.expm1(ms[ix]*np.log1p(-single))
            weights=np.exp(-t0[:,None]*path_links[None,:]/T)
            if model!=0:
                powers=np.full_like(path_links,n-1) if model==1 else path_links
                weights*=pe[:,None]**powers[None,:]*(mem*d2)**(2*(path_links[None,:]-1))
            # No repeated exponentials for every grid point and schedule.
            averages=.5+.5*np.einsum('op,bp->ob',chosen_decay,weights,optimize=False)/len(path_links)
            hi[ix]=np.max(averages,axis=0)
            lo[ix]=np.min(averages,axis=0)
    return hi.reshape(shape),lo.reshape(shape)

@st.cache_data(show_spinner=False)
def grid_data(topology, policy, n, params, max_exact, samples, seed):
    _timing_convention = 'full-link-heralding-independent-extrema-v3'
    prof=profiles(topology,n,max_exact,samples,seed)
    distances=np.linspace(1,200,45) if topology=='chain' else np.linspace(10,40,45)
    delta=np.linspace(0,200,45)
    modes=[10,250,500,1000] if topology=='chain' else [1,5,10,20,35,50]
    D,DT=np.meshgrid(distances,delta);grids={}
    for model in [1,2]:
        for m in modes:grids[model,m]=evaluate(prof,model,D,DT,m,policy,*params)
    return distances,delta,modes,grids

def output(fig, caption, filename, rows):
    st.pyplot(fig,clear_figure=False)
    st.caption(caption)
    buf=io.BytesIO();fig.savefig(buf,format='png',dpi=250,bbox_inches='tight')
    a,b=st.columns(2)
    a.download_button('Download figure (PNG)',buf.getvalue(),filename+'.png','image/png',key=filename+'_png')
    b.download_button('Download data (CSV)',pd.DataFrame(rows).to_csv(index=False).encode(),filename+'.csv','text/csv',key=filename+'_csv')
    plt.close(fig)


def make_fidelity_figure(prof,topology,distance,delta_values,modes,policy,params):
    """Shared paper/app plot formatting with corrected numerical model."""
    plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','font.size':10,'axes.linewidth':.65,'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True,'xtick.minor.visible':True,'ytick.minor.visible':True})
    if topology=='chain':
        fig,axes=plt.subplots(1,3,figsize=(15,4.3),sharey=True)
    else:
        fig,axes=plt.subplots(figsize=(7.4,4.2))
    rows=[]
    for model in [0,1,2]:
        hi,lo=evaluate(prof,model,distance,delta_values,modes,policy,*params)
        ax=axes[model] if topology=='chain' else axes
        if topology=='chain':
            ax.plot(delta_values,hi,color=ORANGE,lw=1.5,label=r'$F_{\mathrm{avg,FI}}^{\max}$')
            ax.plot(delta_values,lo,color=BLUE,ls='--',lw=1.35,label=r'$F_{\mathrm{avg,FI}}^{\min}$')
            ax.set_title(f'Model {model}')
            ax.set_ylim(.65,1.01)
        else:
            ax.plot(delta_values,hi,color=[PURPLE,ORANGE,CORAL][model],label=f'Model {model}')
        ax.set_xlim(0,float(np.max(delta_values)))
        ax.set_xlabel(r'Waiting interval, $\delta_t$ (ms)')
        ax.grid(True,linewidth=.45,alpha=.22)
        rows.extend(dict(model=model,delta_t_ms=float(dt),Favg_max=float(h),Favg_min=float(l)) for dt,h,l in zip(delta_values,hi,lo))
    if topology=='chain':
        axes[0].set_ylabel('Average FI fidelity')
        axes[1].legend(loc='upper center',bbox_to_anchor=(.5,1.22),ncol=2,frameon=False)
        fig.tight_layout(pad=1.0,w_pad=.8)
    else:
        axes.set_ylabel('Average FI fidelity');axes.legend(fontsize=8);fig.tight_layout()
    return fig,rows

def render_dashboard(policy,n,total,T,alpha,d1,d2,rho,mem,fiber,m,delta_values,max_exact,samples,seed,namespace):
    params=(T,alpha,d1,d2,rho,mem,fiber)
    st.caption(f'Baseline exposure: nₚt₀. Swapping success: (ηmem ηd2)²⁽ⁿₚ⁻¹⁾. Selected waiting prescription: {policy}.')
    for topology,figure_no in [('chain',5),('star',8)]:
        st.subheader(f'Figure {figure_no} · '+('Intercity chain' if topology=='chain' else 'Metropolitan star')+' — fidelity and waiting')
        st.markdown('Longer storage reduces entangled-pair quality. The chain shows two execution orders; the uniform star has one network average because its leaf-to-leaf requests share the same waiting-count distribution.')
        prof=profiles(topology,n,int(max_exact),int(samples),int(seed));distance=total/(n-1) if topology=='chain' else 20.
        plot_modes = m if topology=='chain' else int(namespace.get('star_comparison_modes',10))
        fig,rows=make_fidelity_figure(prof,topology,distance,delta_values,plot_modes,policy,params)
        output(fig,f'{n} nodes; elementary-link distance {distance:g} km; m={plot_modes}; {policy}.',f'fig{figure_no}_{topology}_fidelity',rows)
    st.header('Where quantum advantage survives')
    st.markdown('Each panel fixes the number of multiplexing modes and varies link distance and waiting interval. The white dashed line marks F = 2/3; brighter regions indicate higher failure-inclusive fidelity.')
    for topology,num in [('chain',6),('star',9)]:
        st.subheader(f'Figure {num} · '+('Intercity' if topology=='chain' else 'Metropolitan')+' quantum-advantage contours')
        with st.spinner('Calculating contour panels…'):
            ds,dts,modes,grids=grid_data(topology,policy,5,params,int(max_exact),int(samples),int(seed))
        fig=plt.figure(figsize=(15,5.4));outer=fig.add_gridspec(1,2,wspace=.19);rows=[];levels=np.linspace(.5,.92,8)
        for mi,model in enumerate([1,2]):
            inner=outer[mi].subgridspec(2,4 if topology=='chain' else 3,wspace=.22,hspace=.34);mesh=None
            for j,mv in enumerate(modes):
                hi,lo=grids[model,mv]
                for row in ([0,1] if topology=='chain' else [j//3]):
                    col=j if topology=='chain' else j%3
                    ax=fig.add_subplot(inner[row,col]);z=(hi if row==0 else lo) if topology=='chain' else hi
                    mesh=ax.contourf(ds,dts,z,levels=levels,cmap='cividis',extend='max')
                    if z.min()<2/3<z.max():ax.contour(ds,dts,z,levels=[2/3],colors='white',linestyles='--',linewidths=.9)
                    ax.set_title(f'm={mv}',fontsize=8);ax.tick_params(labelsize=7)
                    if col==0:ax.set_ylabel(('Best order\n' if row==0 else 'Worst order\n')+'δt (ms)' if topology=='chain' else 'δt (ms)',fontsize=8)
                    if row==1:ax.set_xlabel('Link distance (km)',fontsize=8)
                rows.extend(dict(model=model,m=mv,distance_km=float(d),delta_t_ms=float(dt),Favg_max=float(hi[y,x]),Favg_min=float(lo[y,x])) for y,dt in enumerate(dts) for x,d in enumerate(ds))
            pos=outer[mi].get_position(fig);fig.text((pos.x0+pos.x1)/2,.96,f'Model {model}',ha='center',fontsize=11)
        fig.subplots_adjust(right=.93,top=.90,bottom=.12);cax=fig.add_axes([.95,.14,.012,.73]);fig.colorbar(mesh,cax=cax,label='Average FI fidelity')
        output(fig,'Five-node paper example. Both models use a common color scale. Contours are sampled on a 45 × 45 grid.',f'fig{num}_{topology}_contours',rows)
    st.header('Link-generation distance limits')
    st.markdown('These legacy plots show the largest total-distance scale at which the link-generation factor reaches 0.99. They depend on multiplexing and attenuation, and are independent of the waiting prescription. This is a link-availability criterion, distinct from the F = 2/3 fidelity boundary above.')
    for topology,num in [('chain',10),('star',11)]:
        st.subheader(f'Figure {num} · '+('Intercity' if topology=='chain' else 'Metropolitan')+' distance versus modes')
        modes=np.unique(np.round(np.logspace(1,4,120)).astype(int));ds=np.linspace(10,650,1281)
        pe=-np.expm1(modes[:,None]*np.log1p(-d1*d1*rho*rho*10**(-alpha*(ds[None,:]/4)/10)))
        fig,axes=plt.subplots(1,2,figsize=(12,4.1),sharey=True);rows=[]
        palette={1:'#9acd32',2:BLUE,3:'#f28e2b',4:'#e15759'}
        for ax,model in zip(axes,[1,2]):
            powers=([4] if topology=='chain' else [2]) if model==1 else ([1,2,3,4] if topology=='chain' else [1,2])
            for power in powers:
                valid=pe**power>=.99;y=np.max(np.where(valid,ds[None,:],-np.inf),axis=1);y[~np.isfinite(y)]=np.nan
                ax.plot(modes,y,color='#9acd32' if model==1 else palette[power],ls='-' if model==1 or power==1 else '--',label=f'Network-wide' if model==1 else f'{power}-link factor')
                rows.extend(dict(model=model,exponent=power,m=int(mv),critical_total_distance_km=float(v)) for mv,v in zip(modes,y))
            ax.set_xscale('log');ax.set_title(f'Model {model}');ax.set_xlabel('Multiplexing modes m');ax.grid(alpha=.2);ax.legend(fontsize=8)
        axes[0].set_ylabel('Critical total distance (km)');fig.tight_layout()
        output(fig,'Fixed five-node legacy geometry; elementary-link factor threshold 0.99. Waiting-time settings do not affect these curves.',f'fig{num}_{topology}_distance',rows)
