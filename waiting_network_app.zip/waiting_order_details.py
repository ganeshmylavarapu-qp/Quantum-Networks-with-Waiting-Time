"""Traceable execution orders, waiting exposures, and numerical network averages."""
import ast
import math
import pandas as pd
import streamlit as st

@st.cache_data(show_spinner=False)
def calculate_orders(topology,n,m,L,dt,T,alpha,d1,d2,rho,mem,fiber,model,max_exact,samples,seed,_evaluate):
    return {policy:_evaluate(topology,n,m,L,dt,T,alpha,d1,d2,rho,mem,fiber,model,max_exact,samples,seed,waiting_mode=policy)
            for policy in ['Repeater-induced waiting','Maximum waiting']}

def render_order_details(namespace):
    st.header('Orders behind the maximum and minimum fidelity')
    n=int(namespace['n_nodes'])
    if n!=5:
        st.info('Select five nodes to see the exact 720-order chain example and its full ten-path calculation.')
        return
    topology=namespace['qa_topology_name'];selected=namespace['waiting_mode']
    m=int(namespace['star_comparison_modes'] if topology=='star' else namespace['m_comparison'])
    dt=float(namespace['delta_t_unit']);T=float(namespace['T']);L=float(namespace['distance_per_link'])
    model=namespace['model_type']
    with st.spinner('Finding maximizing and minimizing execution orders…'):
        results=calculate_orders(topology,n,m,L,dt,T,namespace['alpha'],namespace['eta_d1'],namespace['eta_d2'],namespace['rho'],namespace['eta_mem'],namespace['fiber_index'],model,int(namespace['max_exact_orders']),int(namespace['sample_orders']),int(namespace['random_seed']),namespace['evaluate_topology_for_one_delta_cached'])
    st.markdown('For each complete execution order, calculate the fidelity of all ten source–target paths and take their arithmetic mean. Then select the largest and smallest means **separately for each waiting prescription**. The four direct paths contribute to the mean but do not occupy repeaters.')
    st.caption(f'{model} · {"Intercity chain" if topology=="chain" else "Metropolitan star"} · L={L:g} km · m={m} · δt={dt:g} ms · T={T:g} ms. These extrema apply to this fixed δt, not to every point of the sweep simultaneously.')
    summary=[]
    for policy,result in results.items():
        for extreme,key in [('Maximum','best_df'),('Minimum','worst_df')]:
            df=result[key]
            sequence=' → '.join(df.loc[df['links']>1].sort_values('order')['path'].str.replace('->','–',regex=False))
            summary.append({'Waiting prescription':policy,'Extremum':extreme,'Swapping-path execution order':sequence,'Average FI fidelity':float(df.fidelity.mean()),'Orders evaluated':result['orders_evaluated']})
    summary_df = pd.DataFrame(summary)
    assert len(summary_df) == 4, 'Expected maximum and minimum for each prescription.'
    st.markdown('**Optimal average fidelities**')
    st.table(summary_df[['Waiting prescription', 'Extremum', 'Average FI fidelity', 'Orders evaluated']].set_index(['Waiting prescription', 'Extremum']).round(9))
    st.markdown('**Execution orders producing these four values**')
    order_columns = {}
    for row in summary:
        label = ('RIWT' if row['Waiting prescription'] == 'Repeater-induced waiting' else 'Maximum waiting') + ' · ' + row['Extremum'].lower()
        order_columns[label] = row['Swapping-path execution order'].split(' → ')
    order_table = pd.DataFrame(order_columns)
    order_table.index = pd.RangeIndex(1, len(order_table) + 1, name='Service position')
    st.table(order_table)
    st.caption('RIWT means repeater-induced waiting. Read each column from top to bottom: it is one complete order of the six swapping paths. The four direct paths are included in every average but need no repeater service.')
    st.caption('Each row shows one representative optimum; several orders can tie. Read the arrows between complete path names as service order, not as a new physical route. In a uniform star the leaf-pair ordering is equivalent for the network average.')
    st.download_button('Download all optimal-order summaries (CSV)',pd.DataFrame(summary).to_csv(index=False).encode(),f'{topology}_optimal_order_summary.csv','text/csv',key='optimal_order_summary')
    st.subheader(f'Worked path-by-path calculation · {selected}')
    st.markdown('Select **maximum** or **minimum** below. Changing the waiting prescription in the sidebar changes the optimum used for these detailed tables. To evaluate both prescriptions on one fixed order instead, use the separate same-order comparison table below.')
    tabs=st.tabs(['Maximum average: order and calculation','Minimum average: order and calculation'])
    for tab,extreme,key in zip(tabs,['Maximum','Minimum'],['best_df','worst_df']):
        with tab:
            df=results[selected][key].sort_values('order').copy()
            swapping=df[df.links>1]
            sequence=pd.DataFrame({'Swapping service position':range(1,len(swapping)+1),'Communication path':swapping.path.str.replace('->','–',regex=False).to_list()})
            st.markdown('**1. Execute the six swapping paths in this order**')
            st.table(sequence)
            waiting=[]
            exposure_col='ri_exposure_ms' if selected=='Repeater-induced waiting' else 'max_exposure_ms'
            for _,r in df.iterrows():
                counts=ast.literal_eval(r.waiting_contribution)
                waiting.append({'Path':r.path.replace('->','–'),'Elementary links':int(r.links),'Repeater waiting counts':', '.join(f'R{node}: {count}' for node,count in counts.items()) or 'No swap', 'Repeater availability (ms)':', '.join(f'R{node}: {count*dt:g}' for node,count in counts.items()) or '—','RIWT exposure (ms)':r.ri_exposure_ms,'Maximum-wait exposure (ms)':r.max_exposure_ms,'Selected exposure τ (ms)':r[exposure_col]})
            st.markdown('**2. Calculate waiting and accumulated memory exposure**')
            waiting_df = pd.DataFrame(waiting)
            assert len(waiting_df) == 10, 'Expected all ten source–target paths.'
            st.table(waiting_df[['Path', 'Repeater waiting counts', 'Repeater availability (ms)']].set_index('Path'))
            st.table(waiting_df[['Path', 'Elementary links', 'RIWT exposure (ms)', 'Maximum-wait exposure (ms)', 'Selected exposure τ (ms)']].set_index('Path').style.format(precision=4))
            st.caption('Repeater availability counts are generated by this execution order. The two exposure columns apply different storage prescriptions to the SAME order. Only the selected exposure is used in the fidelity calculation below. All times are in ms.')
            t0=float(df.t0_ms.iloc[0])
            calculation=pd.DataFrame({'Path':df.path.str.replace('->','–',regex=False),'Baseline nₚt₀ (ms)':df.links*t0,'Selected τ (ms)':df[exposure_col],'Total exposure (ms)':df.links*t0+df[exposure_col],'Generation pₑ':df.p_elem,'Swapping success':df.p_swap,'Total success Psucc':df.p_success,'Memory factor D':df.exp_term,'Path FI fidelity':df.fidelity})
            st.markdown('**3. Calculate the fidelity of each path**')
            st.latex(r'D_P=\exp[-(n_Pt_0+\tau_P)/T],\qquad F_{P,\mathrm{FI}}=\frac{1+P_{\mathrm{succ}}(P)D_P}{2}')
            assert len(calculation) == 10, 'Expected ten path-fidelity calculations.'
            st.caption('Storage contribution: baseline plus contention-induced exposure.')
            st.table(calculation[['Path', 'Baseline nₚt₀ (ms)', 'Selected τ (ms)', 'Total exposure (ms)']].set_index('Path').round(6))
            st.caption('Resource-establishment probabilities for each path.')
            st.table(calculation[['Path', 'Generation pₑ', 'Swapping success', 'Total success Psucc']].set_index('Path').round(9))
            st.caption('Final path fidelity: F = (1 + Psucc × D) / 2.')
            st.table(calculation[['Path', 'Total success Psucc', 'Memory factor D', 'Path FI fidelity']].set_index('Path').round(9))
            example=df.iloc[-1]
            st.markdown(f'For example, path **{example.path.replace("->","–")}** has total success probability **{example.p_success:.9f}** and memory factor **{example.exp_term:.9f}**. Its fidelity is **(1 + {example.p_success:.9f} × {example.exp_term:.9f}) / 2 = {example.fidelity:.9f}**. The displayed inputs are rounded; averages below use full precision.')
            st.markdown('**4. Sum all ten fidelities and divide by ten**')
            total=float(df.fidelity.sum());direct=df[df.links==1];indirect=df[df.links>1]
            contributions=pd.DataFrame([{'Contribution':'Four direct paths','Path count':len(direct),'Sum of path fidelities':float(direct.fidelity.sum())},{'Contribution':'Six swapping paths','Path count':len(indirect),'Sum of path fidelities':float(indirect.fidelity.sum())},{'Contribution':'All source–target pairs','Path count':len(df),'Sum of path fidelities':total}])
            st.table(contributions)
            st.latex(r'F_{\mathrm{avg,FI}}=\frac{'+f'{total:.9f}'+r'}{10}='+f'{total/10:.9f}')
            st.metric(f'{extreme} average FI fidelity',f'{total/10:.9f}')
            st.download_button(f'Download {extreme.lower()} waiting calculation (CSV)',pd.DataFrame(waiting).to_csv(index=False).encode(),f'{topology}_{extreme.lower()}_waiting.csv','text/csv',key=f'optimal_{extreme}_waiting')
            st.download_button(f'Download {extreme.lower()} fidelity calculation (CSV)',calculation.to_csv(index=False).encode(),f'{topology}_{extreme.lower()}_fidelity.csv','text/csv',key=f'optimal_{extreme}_fidelity')
