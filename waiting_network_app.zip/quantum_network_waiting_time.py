import io
import math
import random
import itertools
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.colors import BoundaryNorm, LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d import Axes3D
from cycler import cycler
import networkx as nx
import numpy as np
import pandas as pd
import streamlit as st
PHYSREV_COLORS = ['#4c78a8', '#e69f00', '#9acd32', '#e76f51', '#8172b2', '#c46e1a', '#5c9dc7', '#ffbf00', '#a5609c']
PHYSREV_LINESTYLES = ['-', '--', '-.', ':', (0, (3, 1, 1, 1))]
PHYSREV_FIGSIZE = (6.8, 4.2)
PHYSREV_TALL_FIGSIZE = (6.8, 5.2)
PHYSREV_PANEL_FIGSIZE = (6.8, 7.6)
PHYSREV_SURFACE_FIGSIZE = (9.4, 7.0)
PHYSREV_ADVANTAGE_COLOR = (0.88, 0.81, 0.43, 0.78)
PHYSREV_NO_ADVANTAGE_COLOR = (0.42, 0.52, 0.64, 0.78)
PHYSREV_NEUTRAL_LIGHT = '#f7f7f7'
PHYSREV_NEUTRAL_DARK = '#111111'
PHYSREV_NEUTRAL_CONTOUR = 'white'
PHYSREV_LIGHT_CONTOUR = 'white'
PHYSREV_TOPOLOGY_NODE = '#dfe7f2'
METROPOLITAN_LINK_DISTANCE_KM = 20.0
METROPOLITAN_QA_LINK_DISTANCE_VALUES = np.array([10.0, 20.0, 30.0, 40.0], dtype=float)
PHYSREV_FIDELITY_CMAP = plt.get_cmap('cividis')
PHYSREV_DIVERGING_CMAP = LinearSegmentedColormap.from_list('physrev_diverging', [PHYSREV_COLORS[0], PHYSREV_NEUTRAL_LIGHT, PHYSREV_COLORS[3]])

def configure_physrev_style():
    """Apply an APS/Physical Review inspired Matplotlib style without requiring LaTeX."""
    plt.rcParams.update({'figure.dpi': 160, 'savefig.dpi': 300, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02, 'figure.figsize': PHYSREV_FIGSIZE, 'font.family': 'serif', 'font.serif': ['Computer Modern Roman', 'CMU Serif', 'DejaVu Serif'], 'mathtext.fontset': 'cm', 'font.size': 10, 'axes.titlesize': 10, 'axes.labelsize': 10, 'axes.linewidth': 0.65, 'axes.formatter.use_mathtext': False, 'axes.unicode_minus': False, 'axes.prop_cycle': cycler(color=PHYSREV_COLORS), 'lines.linewidth': 1.45, 'lines.markersize': 4.0, 'xtick.direction': 'in', 'ytick.direction': 'in', 'xtick.top': True, 'ytick.right': True, 'xtick.major.size': 4, 'ytick.major.size': 4, 'xtick.minor.size': 2, 'ytick.minor.size': 2, 'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.frameon': False, 'legend.fontsize': 8.5, 'legend.handlelength': 2.2, 'grid.color': '0.82', 'grid.linewidth': 0.45, 'grid.linestyle': '--'})
configure_physrev_style()
st.set_page_config(page_title='Waiting Time in Quantum Networks', layout='wide')
st.markdown('\n<style>\n    .stApp {\n        color: #17231f;\n        background:\n            radial-gradient(circle at 18% 6%, rgba(47, 133, 90, 0.12), transparent 30%),\n            radial-gradient(circle at 92% 14%, rgba(70, 104, 180, 0.10), transparent 26%),\n            linear-gradient(180deg, #f8faf9 0%, #eef3f0 100%);\n    }\n    .stApp,\n    .stApp p,\n    .stApp li,\n    .stApp label,\n    .stApp span,\n    .stApp div,\n    .stApp h1,\n    .stApp h2,\n    .stApp h3,\n    .stApp h4 {\n        color: #17231f;\n    }\n    [data-testid="stSidebar"] {\n        background: #ffffff;\n        border-right: 1px solid #d9e2dc;\n    }\n    [data-testid="stSidebar"] * {\n        color: #17231f;\n    }\n    [data-testid="stMarkdownContainer"] {\n        color: #17231f;\n    }\n    [data-testid="stExpander"] {\n        background-color: #f3faf6 !important;\n        border: 1px solid #cfe1d6 !important;\n        color: #17231f !important;\n    }\n    [data-testid="stExpander"] details {\n        background-color: #f3faf6 !important;\n        color: #17231f !important;\n    }\n    [data-testid="stExpander"] summary {\n        background-color: #e4f2ea !important;\n        color: #17231f !important;\n        border-radius: 0 !important;\n    }\n    [data-testid="stExpander"] summary *,\n    [data-testid="stExpander"] div,\n    [data-testid="stExpander"] p,\n    [data-testid="stExpander"] li,\n    [data-testid="stExpander"] span {\n        color: #17231f !important;\n    }\n    [data-testid="stMetricLabel"],\n    [data-testid="stMetricValue"],\n    [data-testid="stMetricDelta"] {\n        color: #17231f;\n    }\n    div[data-baseweb="select"] > div,\n    div[data-baseweb="input"] > div,\n    input,\n    textarea {\n        color: #17231f !important;\n        background-color: #ffffff !important;\n        border-color: #b8c7bf !important;\n    }\n    div[data-baseweb="select"] span {\n        color: #17231f !important;\n    }\n    code,\n    pre {\n        color: #17231f !important;\n        background-color: #eef5f1 !important;\n    }\n    [data-testid="stDataFrame"],\n    [data-testid="stDataFrame"] div,\n    [data-testid="stDataFrame"] canvas {\n        background-color: #ffffff !important;\n        color: #17231f !important;\n    }\n    [data-testid="stDownloadButton"] button,\n    [data-testid="stDownloadButton"] button[kind="secondary"],\n    .stDownloadButton button,\n    button[kind="secondary"],\n    button[data-testid="baseButton-secondary"],\n    .stApp button {\n        background-color: #e4f2ea !important;\n        color: #17231f !important;\n        border: 1px solid #9fc6af !important;\n        border-radius: 8px !important;\n    }\n    [data-testid="stDownloadButton"] button *,\n    .stDownloadButton button *,\n    button[kind="secondary"] *,\n    button[data-testid="baseButton-secondary"] *,\n    .stApp button * {\n        color: #17231f !important;\n    }\n    [data-testid="stDownloadButton"] button:hover,\n    .stDownloadButton button:hover,\n    button[kind="secondary"]:hover,\n    button[data-testid="baseButton-secondary"]:hover,\n    .stApp button:hover {\n        background-color: #d2eadb !important;\n        border-color: #7fb090 !important;\n        color: #17231f !important;\n    }\n    [data-testid="stTable"],\n    [data-testid="stTable"] * {\n        background-color: #ffffff !important;\n        color: #17231f !important;\n    }\n    .hero {\n        padding: 1.1rem 1.25rem;\n        border: 1px solid #d8e2dc;\n        background: rgba(255, 255, 255, 0.82);\n        margin-bottom: 1rem;\n    }\n    .hero h1 {\n        margin: 0 0 0.35rem 0;\n        font-size: 2rem;\n        letter-spacing: 0;\n        color: #17231f;\n    }\n    .hero p {\n        margin: 0;\n        color: #41524b;\n        font-size: 1rem;\n        line-height: 1.45;\n    }\n    .formula-box {\n        padding: 0.9rem 1rem;\n        border: 1px solid #d8e2dc;\n        background: #ffffff;\n        margin: 0.35rem 0 0.85rem 0;\n    }\n    .small-note {\n        color: #5b6b64;\n        font-size: 0.92rem;\n        line-height: 1.45;\n    }\n</style>\n', unsafe_allow_html=True)


with st.sidebar.expander('Download and test locally'):
    guide_path = Path(__file__).with_name('TESTING_GUIDE.md')
    st.download_button('Download testing guide (.md)', guide_path.read_bytes(), 'TESTING_GUIDE.md', 'text/markdown', key='testing_guide_download')
    source_archive = io.BytesIO()
    import zipfile
    with zipfile.ZipFile(source_archive, 'w', zipfile.ZIP_DEFLATED) as archive:
        source_root = Path(__file__).parent
        for source_name in [Path(__file__).name, 'waiting_app_introduction.py', 'waiting_order_details.py', 'waiting_paper_dashboard.py', 'thesis_plots_full.py', 'TESTING_GUIDE.md', 'requirements.txt']:
            archive.write(source_root / source_name, source_name)
        for asset in sorted((source_root / 'assets').rglob('*')):
            if asset.is_file():
                archive.write(asset, str(asset.relative_to(source_root)))
    st.download_button('Download app source (.zip)', source_archive.getvalue(), 'waiting_network_app.zip', 'application/zip', key='testing_source_download')

waiting_mode = st.sidebar.selectbox('Waiting-time prescription', ['Repeater-induced waiting', 'Maximum waiting'])
show_thesis_plots = st.sidebar.toggle('Show thesis plots', value=False, help='Reveal the full original simulator, including plots outside the paper.')
if show_thesis_plots:
    thesis_source = Path(__file__).with_name('thesis_plots_full.py')
    thesis_code = thesis_source.read_text()
    thesis_code = thesis_code.replace('st.set_page_config(page_title="Quantum Repeater Network Simulator", layout="wide")', '', 1)
    exec(compile(thesis_code, str(thesis_source), 'exec'), globals())
    st.stop()
import sys
if str(Path(__file__).parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).parent))
from waiting_app_introduction import render_introduction
render_introduction()

st.sidebar.title('Network Parameters')
n_nodes = st.sidebar.slider('Number of nodes', 3, 50, 5)
total_distance = st.sidebar.number_input('Total distance (km)', min_value=1.0, value=400.0)
alpha = st.sidebar.number_input('Fiber loss α (dB/km)', min_value=0.0, value=0.21)
m = 1000  # Legacy helpers; paper curves use the topology-specific mode controls.
delta_t_unit = st.sidebar.number_input('Waiting interval δt for table (ms)', min_value=0.0, value=0.1)
T = st.sidebar.number_input('Memory coherence time T (ms)', min_value=1.0, value=200.0)
eta_d1 = st.sidebar.number_input('η_d1', min_value=0.0, max_value=1.0, value=0.95)
eta_d2 = st.sidebar.number_input('η_d2', min_value=0.0, max_value=1.0, value=0.95)
rho = st.sidebar.number_input('ρ', min_value=0.0, max_value=1.0, value=0.9)
eta_mem = st.sidebar.number_input('η_mem', min_value=0.0, max_value=1.0, value=0.95)
model_type = st.sidebar.selectbox('Model for the comparison table', ['Model 0', 'Model 1', 'Model 2'], index=1)
network_type = st.sidebar.selectbox('Network for the comparison table', ['Intercity (Chain)', 'Intracity (Star)'])
if network_type == 'Intracity (Star)':
    distance_per_link = METROPOLITAN_LINK_DISTANCE_KM
    effective_total_distance = distance_per_link * (n_nodes - 1)
    st.sidebar.markdown(f'*Link distance: {distance_per_link:.2f} km (fixed for Metropolitan Network)*')
else:
    distance_per_link = total_distance / (n_nodes - 1)
    effective_total_distance = total_distance
    st.sidebar.markdown(f'*Link distance: {distance_per_link:.2f} km (total / (nodes-1))*')
fiber_index = st.sidebar.number_input('Fiber refractive index', min_value=1.0, value=1.5)
st.sidebar.markdown('---')
st.sidebar.subheader('Order Search')
max_exact_orders = st.sidebar.number_input('Max exact reduced orders', min_value=10, value=100000, step=10)
sample_orders = st.sidebar.number_input('Sampled reduced orders (fallback)', min_value=10, value=300, step=10)
random_seed = st.sidebar.number_input('Random seed', min_value=0, value=7, step=1)
st.sidebar.markdown('---')
st.sidebar.subheader('Sweep Settings')
delta_count = st.sidebar.slider('Δt sweep points', 5, 201, 101)
delta_max = st.sidebar.number_input('Δt sweep max (ms)', min_value=0.1, value=200.0)
st.sidebar.markdown('---')
st.sidebar.subheader('Models 0–2 comparison')
m_comparison = st.sidebar.number_input('Intercity comparison modes', min_value=1, value=1000, step=1)
star_comparison_modes = st.sidebar.number_input('Metropolitan comparison modes', min_value=1, value=10, step=1)
st.sidebar.markdown('---')
st.sidebar.caption('Contour panels use the paper’s fixed five-node parameter ranges.')
qa_link_distance_min = 1.0
qa_link_distance_max = 200.0
qa_link_distance_step = 1.0
qa_delta_t_min = 0.0
qa_delta_t_max = 200.0
qa_delta_t_step = 1.0
st.sidebar.markdown('---')

qa_4d_modes_text = '1,10,100,250,500,1000'
COLOR_CHAIN_MAX = PHYSREV_COLORS[1]
COLOR_CHAIN_MIN = PHYSREV_COLORS[0]
COLOR_STAR = PHYSREV_COLORS[2]
COLOR_MODEL_2_MAX = PHYSREV_COLORS[3]
COLOR_MODEL_2_MIN = PHYSREV_COLORS[6]
COLOR_MODEL_0 = PHYSREV_COLORS[4]

def parse_mode_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [1, 10, 50, 100, 500]

def stepped_values(start, stop, step):
    values = np.arange(float(start), float(stop) + 0.5 * float(step), float(step))
    return values[values <= float(stop) + 1e-09]

def apply_normal_axis_format(ax):
    ax.ticklabel_format(style='plain', axis='y')
    ax.yaxis.get_major_formatter().set_useOffset(False)
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.6f'))
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    ax.grid(True, which='major')
    ax.grid(True, which='minor', linewidth=0.25, alpha=0.18)

def physrev_legend(ax, **kwargs):
    legend = ax.legend(frameon=False, **kwargs)
    return legend

def make_3d_figure():
    fig = plt.figure(figsize=PHYSREV_SURFACE_FIGSIZE)
    fig.subplots_adjust(left=0.04, right=0.96, bottom=0.17, top=0.9)
    ax = fig.add_subplot(1, 1, 1, projection='3d')
    return (fig, ax)

def build_threshold_facecolors(z_grid, threshold=2.0 / 3.0):
    facecolors = np.empty(z_grid.shape + (4,), dtype=float)
    green = np.array(PHYSREV_ADVANTAGE_COLOR)
    red = np.array(PHYSREV_NO_ADVANTAGE_COLOR)
    facecolors[z_grid > threshold] = green
    facecolors[z_grid <= threshold] = red
    return facecolors

def expand_single_distance_grid(x_vals, z_grid, half_width=0.5):
    x_vals = np.asarray(x_vals, dtype=float)
    z_grid = np.asarray(z_grid, dtype=float)
    if len(x_vals) == 1:
        return (np.array([x_vals[0] - half_width, x_vals[0] + half_width], dtype=float), np.repeat(z_grid, 2, axis=1))
    return (x_vals, z_grid)

def plot_threshold_surface_3d(ax, x_vals, y_vals, z_grid, title, z_label):
    x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
    X, Y = np.meshgrid(x_vals, y_vals)
    facecolors = build_threshold_facecolors(z_grid)
    ax.plot_surface(X, Y, z_grid, facecolors=facecolors, rstride=1, cstride=1, linewidth=0.0, antialiased=False, shade=False, edgecolor='none')
    threshold = 2.0 / 3.0
    z_floor = float(np.nanmin(z_grid))
    if z_floor > threshold:
        z_floor = threshold - 0.01
    ax.contour(X, Y, z_grid, levels=[threshold], zdir='z', offset=z_floor, linewidths=1.1, colors=PHYSREV_NEUTRAL_CONTOUR, linestyles='--')
    ax.set_title(title, pad=12)
    ax.set_xlabel('Link distance (km)', labelpad=8)
    ax.set_ylabel('$\\Delta t$ (ms)', labelpad=8)
    ax.set_zlabel(z_label, labelpad=8)
    ax.view_init(elev=24, azim=-128)
    ax.set_zlim(z_floor, max(0.7, float(np.nanmax(z_grid)) + 0.02))
    ax.grid(False)
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.zaxis.set_major_formatter(mticker.FormatStrFormatter('%.3f'))
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.fill = False
        axis.pane.set_edgecolor((1, 1, 1, 0))
        try:
            axis._axinfo['grid']['linewidth'] = 0.0
            axis._axinfo['grid']['color'] = (1, 1, 1, 0)
        except Exception:
            pass
    legend_handles = [Patch(facecolor=PHYSREV_ADVANTAGE_COLOR, label='Advantage: $F>2/3$'), Patch(facecolor=PHYSREV_NO_ADVANTAGE_COLOR, label='No advantage: $F\\leq2/3$')]
    ax.legend(handles=legend_handles, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False)

def plot_modes_delta_surface_3d(ax, mode_vals, delta_vals, z_grid, title, z_label):
    x_plot = np.log10(mode_vals)
    X, Y = np.meshgrid(x_plot, delta_vals)
    facecolors = build_threshold_facecolors(z_grid)
    ax.plot_surface(X, Y, z_grid, facecolors=facecolors, rstride=1, cstride=1, linewidth=0.0, antialiased=False, shade=False, edgecolor='none')
    threshold = 2.0 / 3.0
    z_floor = float(np.nanmin(z_grid))
    if z_floor > threshold:
        z_floor = threshold - 0.01
    if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
        ax.contour(X, Y, z_grid, levels=[threshold], zdir='z', offset=z_floor, linewidths=1.1, colors=PHYSREV_NEUTRAL_CONTOUR, linestyles='--')
    ax.set_title(title, pad=12)
    ax.set_xlabel('Modes, $m$ (log)', labelpad=8)
    ax.set_ylabel('$\\Delta t$ (ms)', labelpad=8)
    ax.set_zlabel(z_label, labelpad=8)
    ax.view_init(elev=24, azim=-128)
    ax.set_zlim(z_floor, max(0.7, float(np.nanmax(z_grid)) + 0.02))
    ax.grid(False)
    tick_candidates = np.array([1, 10, 100, 1000, 10000, 100000], dtype=float)
    tick_candidates = tick_candidates[(tick_candidates >= float(np.min(mode_vals))) & (tick_candidates <= float(np.max(mode_vals)))]
    if len(tick_candidates) == 0:
        tick_candidates = np.array([float(np.min(mode_vals)), float(np.max(mode_vals))])
    ax.set_xticks(np.log10(tick_candidates))
    ax.set_xticklabels([f'{int(v):g}' for v in tick_candidates])
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.zaxis.set_major_formatter(mticker.FormatStrFormatter('%.3f'))
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.fill = False
        axis.pane.set_edgecolor((1, 1, 1, 0))
        try:
            axis._axinfo['grid']['linewidth'] = 0.0
            axis._axinfo['grid']['color'] = (1, 1, 1, 0)
        except Exception:
            pass
    legend_handles = [Patch(facecolor=PHYSREV_ADVANTAGE_COLOR, label='Advantage: $F>2/3$'), Patch(facecolor=PHYSREV_NO_ADVANTAGE_COLOR, label='No advantage: $F\\leq2/3$')]
    ax.legend(handles=legend_handles, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False)

def plot_quantum_advantage_heatmap(ax, x_vals, y_vals, z_grid, title, colorbar_label):
    threshold = 2.0 / 3.0
    x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
    mesh = ax.pcolormesh(x_vals, y_vals, z_grid, shading='auto', cmap=PHYSREV_FIDELITY_CMAP, vmin=max(0.5, float(np.nanmin(z_grid))), vmax=min(1.0, float(np.nanmax(z_grid))))
    if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
        contour = ax.contour(x_vals, y_vals, z_grid, levels=[threshold], colors=PHYSREV_LIGHT_CONTOUR, linewidths=1.2, linestyles='--')
        ax.clabel(contour, fmt={threshold: '$F=2/3$'}, inline=True, fontsize=8)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, pad=0.02)
    cbar.set_label(colorbar_label)
    return mesh

def plot_model_difference_heatmap(ax, x_vals, y_vals, diff_grid, title):
    x_vals, diff_grid = expand_single_distance_grid(x_vals, diff_grid)
    max_abs = float(np.nanmax(np.abs(diff_grid)))
    if max_abs == 0.0:
        max_abs = 1e-06
    mesh = ax.pcolormesh(x_vals, y_vals, diff_grid, shading='auto', cmap=PHYSREV_DIVERGING_CMAP, vmin=-max_abs, vmax=max_abs)
    if float(np.nanmin(diff_grid)) <= 0.0 <= float(np.nanmax(diff_grid)):
        contour = ax.contour(x_vals, y_vals, diff_grid, levels=[0.0], colors=PHYSREV_NEUTRAL_CONTOUR, linewidths=1.0, linestyles='--')
        ax.clabel(contour, fmt={0.0: '$\\Delta F=0$'}, inline=True, fontsize=8)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, pad=0.02)
    cbar.set_label('$\\Delta F = F_{\\mathrm{M2}} - F_{\\mathrm{M1}}$')
    return mesh

def plot_advantage_gain_map(ax, x_vals, y_vals, gain_grid, title):
    x_vals, gain_grid = expand_single_distance_grid(x_vals, gain_grid)
    cmap = ListedColormap([PHYSREV_COLORS[3], PHYSREV_NEUTRAL_LIGHT, PHYSREV_COLORS[2]])
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5], cmap.N)
    mesh = ax.pcolormesh(x_vals, y_vals, gain_grid, shading='auto', cmap=cmap, norm=norm)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, ticks=[-1, 0, 1], pad=0.02)
    cbar.ax.set_yticklabels(['M2 loses', 'same', 'M2 gains'])
    cbar.set_label('Change in $F>2/3$ region')
    return mesh

def plot_4d_mode_slices(df, mode_values, fidelity_col, title, colorbar_label):
    n_modes = len(mode_values)
    ncols = min(3, n_modes)
    nrows = int(math.ceil(n_modes / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(PHYSREV_FIGSIZE[0], 2.45 * nrows), constrained_layout=True, squeeze=False, sharex=True, sharey=True)
    fig.set_constrained_layout_pads(w_pad=0.02, h_pad=0.05, hspace=0.06, wspace=0.04)
    mesh = None
    threshold = 2.0 / 3.0
    vmin = max(0.5, float(np.nanmin(df[fidelity_col])))
    vmax = min(1.0, float(np.nanmax(df[fidelity_col])))
    for idx, mode_value in enumerate(mode_values):
        ax = axes[idx // ncols][idx % ncols]
        sub = df[df['modes'] == int(mode_value)]
        pivot = sub.pivot(index='delta_t_ms', columns='distance_km', values=fidelity_col)
        x_vals = pivot.columns.to_numpy(dtype=float)
        y_vals = pivot.index.to_numpy(dtype=float)
        z_grid = pivot.to_numpy(dtype=float)
        x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
        mesh = ax.pcolormesh(x_vals, y_vals, z_grid, shading='auto', cmap=PHYSREV_FIDELITY_CMAP, vmin=vmin, vmax=vmax)
        if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
            contour = ax.contour(x_vals, y_vals, z_grid, levels=[threshold], colors=PHYSREV_LIGHT_CONTOUR, linewidths=0.95, linestyles='--')
            ax.clabel(contour, fmt={threshold: '$F=2/3$'}, inline=True, fontsize=7)
        ax.set_title(f'$m={int(mode_value)}$')
        ax.minorticks_on()
        ax.tick_params(which='both', direction='in', top=True, right=True)
        ax.grid(False)
    for idx in range(n_modes, nrows * ncols):
        axes[idx // ncols][idx % ncols].axis('off')
    fig.supxlabel('Distance between adjacent nodes (km)', fontsize=10)
    fig.supylabel('Waiting interval, $\\Delta t$ (ms)', fontsize=10)
    fig.suptitle(title, fontsize=10)
    if mesh is not None:
        cbar = fig.colorbar(mesh, ax=axes, pad=0.015, shrink=0.92)
        cbar.set_label(colorbar_label)
    return fig

def critical_distance_vs_modes(topology_name, model_name, mode_values_critical, total_distance_values, alpha_value, eta_d1_value, rho_value, n_nodes_fixed=5, threshold=0.99):
    link_divisor = n_nodes_fixed - 1
    results = {}
    if topology_name == 'chain':
        exponents = [n_nodes_fixed - 1] if model_name == 'Model 1' else [1, 2, 3, 4]
    else:
        exponents = [2] if model_name == 'Model 1' else [1, 2]
    for exponent in exponents:
        results[exponent] = []
    for m_val in mode_values_critical:
        valid_distances = {exp: [] for exp in exponents}
        for total_dist in total_distance_values:
            distance_per_link_here = total_dist / link_divisor
            p_single_here = eta_d1_value ** 2 * rho_value ** 2 * 10 ** (-alpha_value * distance_per_link_here / 10)
            p_elem_here = 1 - (1 - p_single_here) ** m_val
            for exponent in exponents:
                if p_elem_here ** exponent >= threshold:
                    valid_distances[exponent].append(total_dist)
        for exponent in exponents:
            results[exponent].append(max(valid_distances[exponent]) if valid_distances[exponent] else np.nan)
    return results
delta_values = np.linspace(0.0, float(delta_max), int(delta_count))

def parse_node_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [5, 10, 20, 30, 40, 50]

def parse_4d_mode_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(max(1, int(part)))
    return sorted(set(vals)) if vals else [1, 10, 100, 250, 500, 1000]
qa_4d_mode_values = np.array(parse_4d_mode_values(qa_4d_modes_text), dtype=int)

def create_chain(n):
    G = nx.Graph()
    for i in range(1, n):
        G.add_edge(i, i + 1)
    return G

def create_star(n):
    G = nx.Graph()
    center = 1
    for i in range(2, n + 1):
        G.add_edge(center, i)
    return G

def get_positions(graph, topology_name):
    if topology_name == 'chain':
        return {node: (idx, 0.0) for idx, node in enumerate(sorted(graph.nodes()), start=1)}
    return nx.spring_layout(graph, seed=7)

def draw_topology(graph, topology_name):
    fig, ax = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    pos = get_positions(graph, topology_name)
    nx.draw(graph, pos, with_labels=True, node_size=900, node_color=PHYSREV_TOPOLOGY_NODE, edge_color=PHYSREV_COLORS[0], width=2, font_size=11, ax=ax)
    topology_title = 'Intercity Network' if topology_name == 'chain' else 'Metropolitan Network'
    ax.set_title(topology_title)
    ax.axis('off')
    fig.tight_layout()
    return fig

def compute_t0_ms(distance_per_link_km, fiber_index_value):
    c = 300000000.0
    v = c / fiber_index_value
    d_m = distance_per_link_km * 1000.0
    photon_distance_m = d_m  # Outward photon travel plus return herald.
    return photon_distance_m / v * 1000.0

def get_all_paths(graph):
    pairs = list(itertools.combinations(sorted(graph.nodes()), 2))
    return [(u, v, nx.shortest_path(graph, u, v)) for u, v in pairs]

def memory_exposures(path_nodes, repeater_waits):
    """Pair-storage exposure in units of delta_t, excluding baseline storage.

    At a release boundary all ready swaps occur immediately, as in the
    manuscript example. Equal-time swaps add no artificial storage interval.
    """
    n = len(path_nodes) - 1
    if n <= 1:
        return (0, 0)
    max_exposure = n * max(repeater_waits.values(), default=0)
    segments = [(i, i + 1) for i in range(n)]
    exposure = 0
    previous_time = 0
    for time in sorted(set(repeater_waits.values())):
        exposure += len(segments) * (time - previous_time)
        for j in range(1, n):
            if repeater_waits[path_nodes[j]] != time:
                continue
            left = next((seg for seg in segments if seg[1] == j))
            right = next((seg for seg in segments if seg[0] == j))
            segments.remove(left)
            segments.remove(right)
            segments.append((left[0], right[1]))
        previous_time = time
    return (exposure, max_exposure)

def evaluate_order(ordered_paths, waiting_mode='Repeater-induced waiting'):
    node_wait = {}
    rows = []
    for idx, (u, v, p) in enumerate(ordered_paths, start=1):
        intermediate = p[1:-1]
        waits = []
        contrib = {}
        for node in intermediate:
            w = node_wait.get(node, 0)
            waits.append(w)
            contrib[node] = w
            node_wait[node] = w + 1
        max_wait = max(waits) if waits else 0
        ri_exposure, max_exposure = memory_exposures(p, contrib)
        selected_exposure = ri_exposure if waiting_mode == 'Repeater-induced waiting' else max_exposure
        rows.append({'order': idx, 'pair': (u, v), 'path_nodes': p, 'path': '->'.join(map(str, p)), 'links': len(p) - 1, 'waiting': max_wait, 'ri_exposure': ri_exposure, 'max_exposure': max_exposure, 'selected_exposure': selected_exposure, 'waiting_contribution': contrib})
    return rows

def compute_probabilities(n_links, m_value, n_nodes_value, distance_per_link_value, model_name, alpha_value=None, eta_d1_value=None, eta_d2_value=None, rho_value=None, eta_mem_value=None):
    _alpha = alpha_value if alpha_value is not None else alpha
    _eta_d1 = eta_d1_value if eta_d1_value is not None else eta_d1
    _eta_d2 = eta_d2_value if eta_d2_value is not None else eta_d2
    _rho = rho_value if rho_value is not None else rho
    _eta_mem = eta_mem_value if eta_mem_value is not None else eta_mem
    if model_name == 'Model 0':
        p_single = 1.0
        p_elem = 1.0
        p_swap = 1.0
        p_success = 1.0
        return (p_single, p_elem, p_swap, p_success)
    p_single = _eta_d1 ** 2 * _rho ** 2 * 10 ** (-_alpha * distance_per_link_value / 10)
    p_elem = 1 - (1 - p_single) ** m_value
    if n_links == 1:
        p_swap = 1.0
    else:
        p_swap = (_eta_mem * _eta_d2) ** (2 * (n_links - 1))
    if model_name == 'Model 1':
        n_elem = n_nodes_value - 1
        p_success = p_elem ** n_elem * p_swap
    else:
        p_success = p_elem ** n_links * p_swap
    return (p_single, p_elem, p_swap, p_success)

def compute_fidelity(p_success, n_links, waiting, delta_t_unit_value, t0_ms, T_ms, model_name):
    delta_t_ms = waiting * delta_t_unit_value
    exponent_component = (n_links * t0_ms + delta_t_ms) / T_ms
    exp_term = math.exp(-exponent_component)
    p_werner = p_success * exp_term
    fidelity = (1 + p_werner) / 2
    return (fidelity, delta_t_ms, exponent_component, exp_term, p_werner)

def make_table(order_rows, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, t0_value, T_value, model_name, alpha_value=None, eta_d1_value=None, eta_d2_value=None, rho_value=None, eta_mem_value=None, waiting_mode='Repeater-induced waiting'):
    final_rows = []
    for r in order_rows:
        p_single, p_elem, p_swap, p_success = compute_probabilities(r['links'], m_value, n_nodes_value, distance_per_link_value, model_name, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value)
        fidelity, delta_t_ms, exponent_component, exp_term, p_werner = compute_fidelity(p_success=p_success, n_links=r['links'], waiting=r['selected_exposure'], delta_t_unit_value=delta_t_unit_value, t0_ms=t0_value, T_ms=T_value, model_name=model_name)
        final_rows.append({'m': m_value, 'order': r['order'], 'pair': str(r['pair']), 'path': r['path'], 'links': r['links'], 'waiting': r['waiting'], 'ri_exposure_intervals': r['ri_exposure'], 'max_exposure_intervals': r['max_exposure'], 'ri_exposure_ms': r['ri_exposure'] * delta_t_unit_value, 'max_exposure_ms': r['max_exposure'] * delta_t_unit_value, 'waiting_contribution': str(r['waiting_contribution']), 't0_ms': t0_value, 'delta_t_ms': delta_t_ms, 't0_plus_delta_over_T': exponent_component, 'exp_term': exp_term, 'p_single': p_single, 'p_elem': p_elem, 'p_swap': p_swap, 'p_success': p_success, 'p_werner': p_werner, 'fidelity': fidelity, 'raw_path_nodes': r['path_nodes']})
    return pd.DataFrame(final_rows)

def split_zero_and_conflict_paths(paths):
    zero_wait = []
    conflict = []
    for item in paths:
        _, _, p = item
        if len(p) <= 2:
            zero_wait.append(item)
        else:
            conflict.append(item)
    zero_wait = tuple(sorted(zero_wait, key=lambda x: (x[0], x[1])))
    conflict = tuple(sorted(conflict, key=lambda x: (x[0], x[1])))
    return (zero_wait, conflict)

def build_reduced_orders(paths, max_exact, sample_count, seed):
    zero_wait, conflict = split_zero_and_conflict_paths(paths)
    n_conflict = len(conflict)
    total_exact = math.factorial(n_conflict)
    if total_exact <= max_exact:
        orders = [list(zero_wait) + list(perm) for perm in itertools.permutations(conflict)]
        return (orders, 'exact_reduced', len(zero_wait), len(conflict))
    rng = random.Random(seed)
    seen = set()
    sampled = []
    base = tuple((c[0] for c in conflict))
    rev = tuple((c[0] for c in reversed(conflict)))
    for key, cand in [(base, list(conflict)), (rev, list(reversed(conflict)))]:
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + cand)
    attempts = 0
    max_attempts = sample_count * 20
    while len(sampled) < sample_count and attempts < max_attempts:
        attempts += 1
        arr = list(conflict)
        rng.shuffle(arr)
        key = tuple((c[0] for c in arr))
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + arr)
    return (sampled, f'sampled_reduced_{len(sampled)}', len(zero_wait), len(conflict))

@st.cache_data(show_spinner=False)
def quantum_advantage_zone_cached(topology_name, model_name, link_distance_tuple, delta_tuple, m_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """
    Fixed 5-node quantum advantage map for the selected model.
    Sweeps:
      - distance per adjacent link
      - delta_t_unit
    Checks whether average fidelity exceeds 2/3.
    """
    n_nodes_fixed = 5
    threshold = 2.0 / 3.0
    fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    adv_fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)
    adv_fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)
    for i, dt in enumerate(delta_tuple):
        for j, d_link in enumerate(link_distance_tuple):
            res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_fixed, m_value=m_value, distance_per_link_value=float(d_link), delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
            if topology_name == 'star':
                favg = res['favg']
                fmax_grid[i, j] = favg
                fmin_grid[i, j] = favg
                adv_fmax_grid[i, j] = 1 if favg > threshold else 0
                adv_fmin_grid[i, j] = 1 if favg > threshold else 0
            else:
                fmax_grid[i, j] = res['fmax']
                fmin_grid[i, j] = res['fmin']
                adv_fmax_grid[i, j] = 1 if res['fmax'] > threshold else 0
                adv_fmin_grid[i, j] = 1 if res['fmin'] > threshold else 0
    return (fmax_grid, fmin_grid, adv_fmax_grid, adv_fmin_grid)

@st.cache_data(show_spinner=False)
def quantum_advantage_modes_delta_cached(topology_name, model_name, modes_tuple, delta_tuple, n_nodes_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """
    Quantum advantage map for fixed current network parameters.
    Sweeps:
      - multiplexing modes m
      - delta_t_unit
    Checks whether average fidelity exceeds 2/3.
    """
    threshold = 2.0 / 3.0
    fmax_grid = np.zeros((len(delta_tuple), len(modes_tuple)))
    fmin_grid = np.zeros((len(delta_tuple), len(modes_tuple)))
    adv_fmax_grid = np.zeros((len(delta_tuple), len(modes_tuple)), dtype=int)
    adv_fmin_grid = np.zeros((len(delta_tuple), len(modes_tuple)), dtype=int)
    for i, dt in enumerate(delta_tuple):
        for j, mm in enumerate(modes_tuple):
            res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_value, m_value=int(mm), distance_per_link_value=distance_per_link_value, delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
            if topology_name == 'star':
                favg = res['favg']
                fmax_grid[i, j] = favg
                fmin_grid[i, j] = favg
                adv_fmax_grid[i, j] = 1 if favg > threshold else 0
                adv_fmin_grid[i, j] = 1 if favg > threshold else 0
            else:
                fmax_grid[i, j] = res['fmax']
                fmin_grid[i, j] = res['fmin']
                adv_fmax_grid[i, j] = 1 if res['fmax'] > threshold else 0
                adv_fmin_grid[i, j] = 1 if res['fmin'] > threshold else 0
    return (fmax_grid, fmin_grid, adv_fmax_grid, adv_fmin_grid)

@st.cache_data(show_spinner=False)
def quantum_advantage_4d_cached(topology_name, model_name, distance_tuple, delta_tuple, modes_tuple, n_nodes_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    threshold = 2.0 / 3.0
    rows = []
    for mm in modes_tuple:
        for dt in delta_tuple:
            for d_link in distance_tuple:
                res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_value, m_value=int(mm), distance_per_link_value=float(d_link), delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
                if topology_name == 'star':
                    fmax = res['favg']
                    fmin = res['favg']
                else:
                    fmax = res['fmax']
                    fmin = res['fmin']
                rows.append({'distance_km': float(d_link), 'delta_t_ms': float(dt), 'modes': int(mm), 'log10_modes': math.log10(int(mm)), 'fmax': float(fmax), 'fmin': float(fmin), 'adv_fmax': 1 if fmax > threshold else 0, 'adv_fmin': 1 if fmin > threshold else 0})
    return pd.DataFrame(rows)

def evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    graph = create_chain(n_nodes_value) if topology_name == 'chain' else create_star(n_nodes_value)
    paths = get_all_paths(graph)
    orders, eval_mode, zero_count, conflict_count = build_reduced_orders(paths, int(max_exact), int(sample_count), int(seed))
    t0_value = compute_t0_ms(distance_per_link_value, fiber_index_value)
    all_avgF = []
    all_tables = []
    for order in orders:
        rows = evaluate_order(order, waiting_mode=waiting_mode)
        df = make_table(rows, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, t0_value, T_value, model_name, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, waiting_mode=waiting_mode)
        avgF = float(df['fidelity'].mean())
        all_avgF.append(avgF)
        all_tables.append(df)
    if topology_name == 'star':
        avg_val = float(np.mean(all_avgF))
        avg_df = all_tables[int(np.argmax(all_avgF))]
        return {'favg': avg_val, 'fmax': avg_val, 'fmin': avg_val, 'best_df': avg_df, 'worst_df': avg_df, 'eval_mode': 'single_average_star', 'orders_evaluated': len(all_avgF), 'zero_paths': zero_count, 'conflict_paths': conflict_count}
    best_idx = int(np.argmax(all_avgF))
    worst_idx = int(np.argmin(all_avgF))
    return {'fmax': all_avgF[best_idx], 'fmin': all_avgF[worst_idx], 'best_df': all_tables[best_idx], 'worst_df': all_tables[worst_idx], 'eval_mode': eval_mode, 'orders_evaluated': len(orders), 'zero_paths': zero_count, 'conflict_paths': conflict_count}

@st.cache_data(show_spinner=False)
def modes_sweep_cached(topology_name, modes_tuple, n_nodes_value, distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    best_vals = []
    worst_vals = []
    for mm in modes_tuple:
        res = evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, int(mm), distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        best_vals.append(res['fmax'])
        worst_vals.append(res['fmin'])
    return (best_vals, worst_vals)

@st.cache_data(show_spinner=False)
def delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    best_vals = []
    worst_vals = []
    for dt in deltas_tuple:
        res = evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, m_value, distance_per_link_value, float(dt), T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        best_vals.append(res['fmax'])
        worst_vals.append(res['fmin'])
    return (best_vals, worst_vals)

@st.cache_data(show_spinner=False)
def multi_node_delta_sweep_cached(node_counts_tuple, deltas_tuple, m_value, total_distance_value, fixed_distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """For each node count, compute star average fidelity across delta_t values."""
    results = {}
    for n in node_counts_tuple:
        if fixed_distance_per_link_value is None:
            dist_per_link = total_distance_value / (n - 1)
        else:
            dist_per_link = fixed_distance_per_link_value
        star_vals, _ = delta_sweep_cached('star', deltas_tuple, n, m_value, dist_per_link, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        results[n] = star_vals
    return results

@st.cache_data(show_spinner=False)
def model_comparison_delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """Compute delta sweep for Model 0, Model 1, and Model 2 for comparison."""
    best_m0, worst_m0 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 0', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    best_m1, worst_m1 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 1', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    best_m2, worst_m2 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 2', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    return (best_m0, worst_m0, best_m1, worst_m1, best_m2, worst_m2)

def make_excel_bytes(sheets_dict):
    output = io.BytesIO()
    try:
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            for sheet_name, df in sheets_dict.items():
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        output.seek(0)
        return output.getvalue()
    except Exception:
        return None

def representative_path_links(topology_name, n_nodes_value):
    if topology_name == 'chain':
        return n_nodes_value - 1
    else:
        return 2 if n_nodes_value > 2 else 1
figure_family = 'Fidelity'  # All six paper figure groups are displayed below.
qa_topology_name = 'chain' if network_type == 'Intercity (Chain)' else 'star'
st.header('Paper figures')
st.caption('All six numerical figure groups appear below. The waiting prescription applies to both topologies; extra thesis plots remain available from the sidebar.')
st.caption(f"Selected prescription: {waiting_mode}. RIWT counts storage of elementary and intermediate entangled pairs; maximum waiting holds every elementary pair until the last required repeater is available.")
from waiting_order_details import render_order_details
render_order_details(globals())

if n_nodes == 5:
    with st.expander("Five-node waiting-time comparison and path data", expanded=True):
        example_schedule = st.selectbox("Communication order for comparison", ["Best order for selected prescription", "Worst order for selected prescription", "Shortest paths first (fixed order)"])
        example_modes = int(star_comparison_modes) if qa_topology_name == 'star' else int(m_comparison)
        example_t0 = compute_t0_ms(distance_per_link, fiber_index)
        if example_schedule.startswith('Shortest'):
            example_graph = create_chain(5) if qa_topology_name == 'chain' else create_star(5)
            example_paths = sorted(get_all_paths(example_graph), key=lambda item: (len(item[2]), item[0], item[1]))
            example_rows = evaluate_order(example_paths, waiting_mode=waiting_mode)
            example_df = make_table(example_rows, 5, example_modes, distance_per_link, delta_t_unit, example_t0, T, model_type, alpha, eta_d1, eta_d2, rho, eta_mem, waiting_mode=waiting_mode)
        else:
            example_result = evaluate_topology_for_one_delta_cached(qa_topology_name, 5, example_modes, distance_per_link, delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
            example_df = example_result['best_df' if example_schedule.startswith('Best') else 'worst_df'].copy()
        comparison_data = example_df[['order', 'path', 'links', 'waiting_contribution', 'ri_exposure_intervals', 'max_exposure_intervals', 'ri_exposure_ms', 'max_exposure_ms']].copy()
        ri_factor = np.exp(-(example_df['links'] * example_t0 + example_df['ri_exposure_ms']) / T)
        max_factor = np.exp(-(example_df['links'] * example_t0 + example_df['max_exposure_ms']) / T)
        comparison_data['FI fidelity: repeater-induced'] = (1 + example_df['p_success'] * ri_factor) / 2
        comparison_data['FI fidelity: maximum waiting'] = (1 + example_df['p_success'] * max_factor) / 2
        comparison_data = comparison_data.rename(columns={'order': 'Service order', 'path': 'Path', 'links': 'Elementary links', 'waiting_contribution': 'Repeater waiting counts', 'ri_exposure_intervals': 'RIWT exposure / delta_t', 'max_exposure_intervals': 'Maximum exposure / delta_t', 'ri_exposure_ms': 'RIWT exposure (ms)', 'max_exposure_ms': 'Maximum exposure (ms)'})
        st.caption(f"Both columns use the SAME communication order. {model_type}, m={example_modes}, delta_t={delta_t_unit:g} ms. The displayed order is chosen using {waiting_mode}. Both table columns evaluate that same order; the graphs independently optimize each prescription. These are accumulated pair-storage exposures, not elapsed path delays.")
        assert len(comparison_data) == 10, 'Expected all ten source–target paths.'
        st.markdown('**Execution order and repeater waiting counts**')
        st.table(comparison_data[['Service order', 'Path', 'Elementary links', 'Repeater waiting counts']].set_index('Service order'))
        st.markdown('**Memory exposure for the same execution order**')
        st.table(comparison_data[['Path', 'RIWT exposure / delta_t', 'Maximum exposure / delta_t', 'RIWT exposure (ms)', 'Maximum exposure (ms)']].set_index('Path').round(6))
        st.markdown('**Path fidelities under the two waiting prescriptions**')
        st.table(comparison_data[['Path', 'FI fidelity: repeater-induced', 'FI fidelity: maximum waiting']].set_index('Path').round(9))
        c_ri, c_max = st.columns(2)
        c_ri.metric('Average FI fidelity: repeater-induced', f"{comparison_data['FI fidelity: repeater-induced'].mean():.6f}")
        c_max.metric('Average FI fidelity: maximum waiting', f"{comparison_data['FI fidelity: maximum waiting'].mean():.6f}")
        st.download_button('Download waiting comparison (CSV)', comparison_data.to_csv(index=False).encode('utf-8'), f'{qa_topology_name}_five_node_waiting_comparison.csv', 'text/csv')
else:
    st.info('Select five nodes to show the path-by-path waiting comparison table.')

import sys
if str(Path(__file__).parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).parent))
from waiting_paper_dashboard import render_dashboard
render_dashboard(waiting_mode, n_nodes, total_distance, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, int(m_comparison), delta_values, max_exact_orders, sample_orders, random_seed, globals())
