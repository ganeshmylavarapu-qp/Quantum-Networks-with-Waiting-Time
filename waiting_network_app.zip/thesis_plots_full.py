import io
import math
import random
import itertools
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.colors import BoundaryNorm, LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d import Axes3D
from cycler import cycler
import networkx as nx
import numpy as np
import pandas as pd
import streamlit as st
PHYSREV_COLORS = ['#4c78a8', '#e69f00', '#9acd32', '#e76f51', '#8172b2', '#c46e1a', '#5c9dc7', '#ffbf00', '#a5609c']
PHYSREV_LINESTYLES = ['-', '--', '-.', ':', (0, (3, 1, 1, 1))]
PHYSREV_FIGSIZE = (6.8, 4.2)
PHYSREV_TALL_FIGSIZE = (6.8, 5.2)
PHYSREV_PANEL_FIGSIZE = (6.8, 7.6)
PHYSREV_SURFACE_FIGSIZE = (9.4, 7.0)
PHYSREV_ADVANTAGE_COLOR = (0.88, 0.81, 0.43, 0.78)
PHYSREV_NO_ADVANTAGE_COLOR = (0.42, 0.52, 0.64, 0.78)
PHYSREV_NEUTRAL_LIGHT = '#f7f7f7'
PHYSREV_NEUTRAL_DARK = '#111111'
PHYSREV_NEUTRAL_CONTOUR = 'white'
PHYSREV_LIGHT_CONTOUR = 'white'
PHYSREV_TOPOLOGY_NODE = '#dfe7f2'
METROPOLITAN_LINK_DISTANCE_KM = 20.0
METROPOLITAN_QA_LINK_DISTANCE_VALUES = np.array([10.0, 20.0, 30.0, 40.0], dtype=float)
PHYSREV_FIDELITY_CMAP = plt.get_cmap('cividis')
PHYSREV_DIVERGING_CMAP = LinearSegmentedColormap.from_list('physrev_diverging', [PHYSREV_COLORS[0], PHYSREV_NEUTRAL_LIGHT, PHYSREV_COLORS[3]])

def configure_physrev_style():
    """Apply an APS/Physical Review inspired Matplotlib style without requiring LaTeX."""
    plt.rcParams.update({'figure.dpi': 160, 'savefig.dpi': 300, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02, 'figure.figsize': PHYSREV_FIGSIZE, 'font.family': 'serif', 'font.serif': ['Computer Modern Roman', 'CMU Serif', 'DejaVu Serif'], 'mathtext.fontset': 'cm', 'font.size': 10, 'axes.titlesize': 10, 'axes.labelsize': 10, 'axes.linewidth': 0.65, 'axes.formatter.use_mathtext': False, 'axes.unicode_minus': False, 'axes.prop_cycle': cycler(color=PHYSREV_COLORS), 'lines.linewidth': 1.45, 'lines.markersize': 4.0, 'xtick.direction': 'in', 'ytick.direction': 'in', 'xtick.top': True, 'ytick.right': True, 'xtick.major.size': 4, 'ytick.major.size': 4, 'xtick.minor.size': 2, 'ytick.minor.size': 2, 'xtick.labelsize': 9, 'ytick.labelsize': 9, 'legend.frameon': False, 'legend.fontsize': 8.5, 'legend.handlelength': 2.2, 'grid.color': '0.82', 'grid.linewidth': 0.45, 'grid.linestyle': '--'})
configure_physrev_style()
st.set_page_config(page_title='Quantum Repeater Network Simulator', layout='wide')
if 'waiting_mode' not in globals():
    waiting_mode = st.sidebar.selectbox('Waiting-time prescription', ['Repeater-induced waiting', 'Maximum waiting'])
st.title('Quantum Repeater Network Simulator')
st.sidebar.title('Network Parameters')
n_nodes = st.sidebar.slider('Number of nodes', 3, 50, 5)
total_distance = st.sidebar.number_input('Total distance (km)', min_value=1.0, value=250.0)
alpha = st.sidebar.number_input('Fiber loss α (dB/km)', min_value=0.0, value=0.21)
m = st.sidebar.number_input('Multiplexing modes m', min_value=1, value=1000)
delta_t_unit = st.sidebar.number_input('Δt unit (ms)', min_value=0.0, value=0.1)
T = st.sidebar.number_input('Memory coherence time T (ms)', min_value=1.0, value=200.0)
eta_d1 = st.sidebar.number_input('η_d1', min_value=0.0, max_value=1.0, value=0.9)
eta_d2 = st.sidebar.number_input('η_d2', min_value=0.0, max_value=1.0, value=0.9)
rho = st.sidebar.number_input('ρ', min_value=0.0, max_value=1.0, value=0.9)
eta_mem = st.sidebar.number_input('η_mem', min_value=0.0, max_value=1.0, value=0.9)
model_type = st.sidebar.selectbox('Model Type', ['Model 0', 'Model 1', 'Model 2'])
network_type = st.sidebar.selectbox('Network Type', ['Intercity (Chain)', 'Intracity (Star)'])
if network_type == 'Intracity (Star)':
    distance_per_link = METROPOLITAN_LINK_DISTANCE_KM
    effective_total_distance = distance_per_link * (n_nodes - 1)
    st.sidebar.markdown(f'*Link distance: {distance_per_link:.2f} km (fixed for Metropolitan Network)*')
else:
    distance_per_link = total_distance / (n_nodes - 1)
    effective_total_distance = total_distance
    st.sidebar.markdown(f'*Link distance: {distance_per_link:.2f} km (total / (nodes-1))*')
fiber_index = st.sidebar.number_input('Fiber refractive index', min_value=1.0, value=1.5)
st.sidebar.markdown('---')
st.sidebar.subheader('Order Search')
max_exact_orders = st.sidebar.number_input('Max exact reduced orders', min_value=10, value=100000, step=10)
sample_orders = st.sidebar.number_input('Sampled reduced orders (fallback)', min_value=10, value=300, step=10)
random_seed = st.sidebar.number_input('Random seed', min_value=0, value=7, step=1)
st.sidebar.markdown('---')
st.sidebar.subheader('Sweep Settings')
mode_values_text = st.sidebar.text_input('Modes sweep values', '1,10,50,100,500')
delta_count = st.sidebar.slider('Δt sweep points', 5, 60, 30)
delta_max = st.sidebar.number_input('Δt sweep max (ms)', min_value=0.1, value=200.0)
st.sidebar.markdown('---')
st.sidebar.subheader('Multi-Node Metropolitan Network Sweep')
multi_node_values_text = st.sidebar.text_input('Node counts for Metropolitan Network sweep', '5,10,20,30,40,50')
st.sidebar.markdown('---')
st.sidebar.subheader('Selected-Model View Settings')
m_comparison = st.sidebar.number_input('Modes m for Model comparison', min_value=1, value=10, step=1)
st.sidebar.markdown('*Used for the selected-model Δt comparison if you want a second fixed-m view.*')
st.sidebar.markdown('---')
st.sidebar.subheader('Quantum Advantage Zone')
qa_link_distance_min = st.sidebar.number_input('QA link distance min (km)', min_value=1.0, value=5.0, key='qa_link_distance_min')
qa_link_distance_max = st.sidebar.number_input('QA link distance max (km)', min_value=qa_link_distance_min, value=200.0, key='qa_link_distance_max')
qa_link_distance_step = st.sidebar.number_input('QA link distance step (km)', min_value=0.1, value=1.0, key='qa_link_distance_step')
qa_delta_t_min = st.sidebar.number_input('QA Δt min (ms)', min_value=0.0, value=0.0, key='qa_delta_t_min')
qa_delta_t_max = st.sidebar.number_input('QA Δt max (ms)', min_value=qa_delta_t_min + 0.1, value=200.0, key='qa_delta_t_max')
qa_delta_t_step = st.sidebar.number_input('QA Δt step (ms)', min_value=0.1, value=1.0, key='qa_delta_t_step')
qa_modes_min = st.sidebar.number_input('QA modes min', min_value=1, value=1, step=1, key='qa_modes_min')
qa_modes_max = st.sidebar.number_input('QA modes max', min_value=qa_modes_min, value=10000, step=1, key='qa_modes_max')
qa_modes_points = st.sidebar.slider('QA modes sweep points', 5, 80, 35, key='qa_modes_points')
st.sidebar.markdown('---')
st.sidebar.subheader('4D Advantage Zone')
qa_4d_modes_text = st.sidebar.text_input('4D modes values', '1,10,100,250,500,1000', key='qa_4d_modes_text')
COLOR_CHAIN_MAX = PHYSREV_COLORS[1]
COLOR_CHAIN_MIN = PHYSREV_COLORS[0]
COLOR_STAR = PHYSREV_COLORS[2]
COLOR_MODEL_2_MAX = PHYSREV_COLORS[3]
COLOR_MODEL_2_MIN = PHYSREV_COLORS[6]
COLOR_MODEL_0 = PHYSREV_COLORS[4]

def parse_mode_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [1, 10, 50, 100, 500]

def stepped_values(start, stop, step):
    values = np.arange(float(start), float(stop) + 0.5 * float(step), float(step))
    return values[values <= float(stop) + 1e-09]

def apply_normal_axis_format(ax):
    ax.ticklabel_format(style='plain', axis='y')
    ax.yaxis.get_major_formatter().set_useOffset(False)
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.6f'))
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    ax.grid(True, which='major')
    ax.grid(True, which='minor', linewidth=0.25, alpha=0.18)

def physrev_legend(ax, **kwargs):
    legend = ax.legend(frameon=False, **kwargs)
    return legend

def make_3d_figure():
    fig = plt.figure(figsize=PHYSREV_SURFACE_FIGSIZE)
    fig.subplots_adjust(left=0.04, right=0.96, bottom=0.17, top=0.9)
    ax = fig.add_subplot(1, 1, 1, projection='3d')
    return (fig, ax)

def build_threshold_facecolors(z_grid, threshold=2.0 / 3.0):
    facecolors = np.empty(z_grid.shape + (4,), dtype=float)
    green = np.array(PHYSREV_ADVANTAGE_COLOR)
    red = np.array(PHYSREV_NO_ADVANTAGE_COLOR)
    facecolors[z_grid > threshold] = green
    facecolors[z_grid <= threshold] = red
    return facecolors

def expand_single_distance_grid(x_vals, z_grid, half_width=0.5):
    x_vals = np.asarray(x_vals, dtype=float)
    z_grid = np.asarray(z_grid, dtype=float)
    if len(x_vals) == 1:
        return (np.array([x_vals[0] - half_width, x_vals[0] + half_width], dtype=float), np.repeat(z_grid, 2, axis=1))
    return (x_vals, z_grid)

def plot_threshold_surface_3d(ax, x_vals, y_vals, z_grid, title, z_label):
    x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
    X, Y = np.meshgrid(x_vals, y_vals)
    facecolors = build_threshold_facecolors(z_grid)
    ax.plot_surface(X, Y, z_grid, facecolors=facecolors, rstride=1, cstride=1, linewidth=0.0, antialiased=False, shade=False, edgecolor='none')
    threshold = 2.0 / 3.0
    z_floor = float(np.nanmin(z_grid))
    if z_floor > threshold:
        z_floor = threshold - 0.01
    ax.contour(X, Y, z_grid, levels=[threshold], zdir='z', offset=z_floor, linewidths=1.1, colors=PHYSREV_NEUTRAL_CONTOUR, linestyles='--')
    ax.set_title(title, pad=12)
    ax.set_xlabel('Link distance (km)', labelpad=8)
    ax.set_ylabel('$\\Delta t$ (ms)', labelpad=8)
    ax.set_zlabel(z_label, labelpad=8)
    ax.view_init(elev=24, azim=-128)
    ax.set_zlim(z_floor, max(0.7, float(np.nanmax(z_grid)) + 0.02))
    ax.grid(False)
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.zaxis.set_major_formatter(mticker.FormatStrFormatter('%.3f'))
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.fill = False
        axis.pane.set_edgecolor((1, 1, 1, 0))
        try:
            axis._axinfo['grid']['linewidth'] = 0.0
            axis._axinfo['grid']['color'] = (1, 1, 1, 0)
        except Exception:
            pass
    legend_handles = [Patch(facecolor=PHYSREV_ADVANTAGE_COLOR, label='Advantage: $F>2/3$'), Patch(facecolor=PHYSREV_NO_ADVANTAGE_COLOR, label='No advantage: $F\\leq2/3$')]
    ax.legend(handles=legend_handles, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False)

def plot_modes_delta_surface_3d(ax, mode_vals, delta_vals, z_grid, title, z_label):
    x_plot = np.log10(mode_vals)
    X, Y = np.meshgrid(x_plot, delta_vals)
    facecolors = build_threshold_facecolors(z_grid)
    ax.plot_surface(X, Y, z_grid, facecolors=facecolors, rstride=1, cstride=1, linewidth=0.0, antialiased=False, shade=False, edgecolor='none')
    threshold = 2.0 / 3.0
    z_floor = float(np.nanmin(z_grid))
    if z_floor > threshold:
        z_floor = threshold - 0.01
    if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
        ax.contour(X, Y, z_grid, levels=[threshold], zdir='z', offset=z_floor, linewidths=1.1, colors=PHYSREV_NEUTRAL_CONTOUR, linestyles='--')
    ax.set_title(title, pad=12)
    ax.set_xlabel('Modes, $m$ (log)', labelpad=8)
    ax.set_ylabel('$\\Delta t$ (ms)', labelpad=8)
    ax.set_zlabel(z_label, labelpad=8)
    ax.view_init(elev=24, azim=-128)
    ax.set_zlim(z_floor, max(0.7, float(np.nanmax(z_grid)) + 0.02))
    ax.grid(False)
    tick_candidates = np.array([1, 10, 100, 1000, 10000, 100000], dtype=float)
    tick_candidates = tick_candidates[(tick_candidates >= float(np.min(mode_vals))) & (tick_candidates <= float(np.max(mode_vals)))]
    if len(tick_candidates) == 0:
        tick_candidates = np.array([float(np.min(mode_vals)), float(np.max(mode_vals))])
    ax.set_xticks(np.log10(tick_candidates))
    ax.set_xticklabels([f'{int(v):g}' for v in tick_candidates])
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%g'))
    ax.zaxis.set_major_formatter(mticker.FormatStrFormatter('%.3f'))
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.fill = False
        axis.pane.set_edgecolor((1, 1, 1, 0))
        try:
            axis._axinfo['grid']['linewidth'] = 0.0
            axis._axinfo['grid']['color'] = (1, 1, 1, 0)
        except Exception:
            pass
    legend_handles = [Patch(facecolor=PHYSREV_ADVANTAGE_COLOR, label='Advantage: $F>2/3$'), Patch(facecolor=PHYSREV_NO_ADVANTAGE_COLOR, label='No advantage: $F\\leq2/3$')]
    ax.legend(handles=legend_handles, loc='upper left', bbox_to_anchor=(0.02, 0.98), frameon=False)

def plot_quantum_advantage_heatmap(ax, x_vals, y_vals, z_grid, title, colorbar_label):
    threshold = 2.0 / 3.0
    x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
    mesh = ax.pcolormesh(x_vals, y_vals, z_grid, shading='auto', cmap=PHYSREV_FIDELITY_CMAP, vmin=max(0.5, float(np.nanmin(z_grid))), vmax=min(1.0, float(np.nanmax(z_grid))))
    if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
        contour = ax.contour(x_vals, y_vals, z_grid, levels=[threshold], colors=PHYSREV_LIGHT_CONTOUR, linewidths=1.2, linestyles='--')
        ax.clabel(contour, fmt={threshold: '$F=2/3$'}, inline=True, fontsize=8)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, pad=0.02)
    cbar.set_label(colorbar_label)
    return mesh

def plot_model_difference_heatmap(ax, x_vals, y_vals, diff_grid, title):
    x_vals, diff_grid = expand_single_distance_grid(x_vals, diff_grid)
    max_abs = float(np.nanmax(np.abs(diff_grid)))
    if max_abs == 0.0:
        max_abs = 1e-06
    mesh = ax.pcolormesh(x_vals, y_vals, diff_grid, shading='auto', cmap=PHYSREV_DIVERGING_CMAP, vmin=-max_abs, vmax=max_abs)
    if float(np.nanmin(diff_grid)) <= 0.0 <= float(np.nanmax(diff_grid)):
        contour = ax.contour(x_vals, y_vals, diff_grid, levels=[0.0], colors=PHYSREV_NEUTRAL_CONTOUR, linewidths=1.0, linestyles='--')
        ax.clabel(contour, fmt={0.0: '$\\Delta F=0$'}, inline=True, fontsize=8)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, pad=0.02)
    cbar.set_label('$\\Delta F = F_{\\mathrm{M2}} - F_{\\mathrm{M1}}$')
    return mesh

def plot_advantage_gain_map(ax, x_vals, y_vals, gain_grid, title):
    x_vals, gain_grid = expand_single_distance_grid(x_vals, gain_grid)
    cmap = ListedColormap([PHYSREV_COLORS[3], PHYSREV_NEUTRAL_LIGHT, PHYSREV_COLORS[2]])
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5], cmap.N)
    mesh = ax.pcolormesh(x_vals, y_vals, gain_grid, shading='auto', cmap=cmap, norm=norm)
    ax.set_title(title)
    ax.set_xlabel('Distance between adjacent nodes (km)')
    ax.set_ylabel('Waiting interval, $\\Delta t$ (ms)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)
    cbar = ax.figure.colorbar(mesh, ax=ax, ticks=[-1, 0, 1], pad=0.02)
    cbar.ax.set_yticklabels(['M2 loses', 'same', 'M2 gains'])
    cbar.set_label('Change in $F>2/3$ region')
    return mesh

def plot_4d_mode_slices(df, mode_values, fidelity_col, title, colorbar_label):
    n_modes = len(mode_values)
    ncols = min(3, n_modes)
    nrows = int(math.ceil(n_modes / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(PHYSREV_FIGSIZE[0], 2.45 * nrows), constrained_layout=True, squeeze=False, sharex=True, sharey=True)
    fig.set_constrained_layout_pads(w_pad=0.02, h_pad=0.05, hspace=0.06, wspace=0.04)
    mesh = None
    threshold = 2.0 / 3.0
    vmin = max(0.5, float(np.nanmin(df[fidelity_col])))
    vmax = min(1.0, float(np.nanmax(df[fidelity_col])))
    for idx, mode_value in enumerate(mode_values):
        ax = axes[idx // ncols][idx % ncols]
        sub = df[df['modes'] == int(mode_value)]
        pivot = sub.pivot(index='delta_t_ms', columns='distance_km', values=fidelity_col)
        x_vals = pivot.columns.to_numpy(dtype=float)
        y_vals = pivot.index.to_numpy(dtype=float)
        z_grid = pivot.to_numpy(dtype=float)
        x_vals, z_grid = expand_single_distance_grid(x_vals, z_grid)
        mesh = ax.pcolormesh(x_vals, y_vals, z_grid, shading='auto', cmap=PHYSREV_FIDELITY_CMAP, vmin=vmin, vmax=vmax)
        if float(np.nanmin(z_grid)) <= threshold <= float(np.nanmax(z_grid)):
            contour = ax.contour(x_vals, y_vals, z_grid, levels=[threshold], colors=PHYSREV_LIGHT_CONTOUR, linewidths=0.95, linestyles='--')
            ax.clabel(contour, fmt={threshold: '$F=2/3$'}, inline=True, fontsize=7)
        ax.set_title(f'$m={int(mode_value)}$')
        ax.minorticks_on()
        ax.tick_params(which='both', direction='in', top=True, right=True)
        ax.grid(False)
    for idx in range(n_modes, nrows * ncols):
        axes[idx // ncols][idx % ncols].axis('off')
    fig.supxlabel('Distance between adjacent nodes (km)', fontsize=10)
    fig.supylabel('Waiting interval, $\\Delta t$ (ms)', fontsize=10)
    fig.suptitle(title, fontsize=10)
    if mesh is not None:
        cbar = fig.colorbar(mesh, ax=axes, pad=0.015, shrink=0.92)
        cbar.set_label(colorbar_label)
    return fig

def critical_distance_vs_modes(topology_name, model_name, mode_values_critical, total_distance_values, alpha_value, eta_d1_value, rho_value, n_nodes_fixed=5, threshold=0.99):
    link_divisor = n_nodes_fixed - 1
    results = {}
    if topology_name == 'chain':
        exponents = [n_nodes_fixed - 1] if model_name == 'Model 1' else [1, 2, 3, 4]
    else:
        exponents = [2] if model_name == 'Model 1' else [1, 2]
    for exponent in exponents:
        results[exponent] = []
    for m_val in mode_values_critical:
        valid_distances = {exp: [] for exp in exponents}
        for total_dist in total_distance_values:
            distance_per_link_here = total_dist / link_divisor
            p_single_here = eta_d1_value ** 2 * rho_value ** 2 * 10 ** (-alpha_value * distance_per_link_here / 10)
            p_elem_here = 1 - (1 - p_single_here) ** m_val
            for exponent in exponents:
                if p_elem_here ** exponent >= threshold:
                    valid_distances[exponent].append(total_dist)
        for exponent in exponents:
            results[exponent].append(max(valid_distances[exponent]) if valid_distances[exponent] else np.nan)
    return results
mode_values = parse_mode_values(mode_values_text)
delta_values = np.linspace(0.1, float(delta_max), int(delta_count))

def parse_node_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(int(part))
    return vals if vals else [5, 10, 20, 30, 40, 50]
multi_node_values = parse_node_values(multi_node_values_text)

def parse_4d_mode_values(text: str):
    vals = []
    for part in text.split(','):
        part = part.strip()
        if part:
            vals.append(max(1, int(part)))
    return sorted(set(vals)) if vals else [1, 10, 100, 250, 500, 1000]
qa_4d_mode_values = np.array(parse_4d_mode_values(qa_4d_modes_text), dtype=int)
st.subheader('Quantum Repeater Architecture')
image_path = Path('repeater_architecture.png')
if image_path.exists():
    st.image(str(image_path), caption='Reference quantum repeater architecture used for conceptual illustration. Photons travel L/2 to the BSM stations, while repeater nodes perform memory storage and swapping.', use_container_width=True)
else:
    st.info('Place your image in the same folder as app.py with the filename `repeater_architecture.png` to display it here.')
st.subheader('Physical Model')
if model_type == 'Model 0':
    st.markdown('\n### Model 0 — Decoherence-Only Reference Model\n\nModel 0 is an idealized baseline in which elementary-link generation and entanglement swapping are assumed perfect.\n\n#### Elementary link and swapping assumptions\nWe set\n\n$$\np_{\\mathrm{elem}} = 1,\n\\qquad\np_{\\mathrm{swap}} = 1,\n\\qquad\np_{\\mathrm{success}} = 1.\n$$\n\nThus, the only reduction in fidelity comes from storage-induced decoherence.\n\n#### Decoherence model\nFor one elementary link, the Werner parameter is taken as\n\n$$\np_{\\mathrm{werner}} =\n\\exp\\!\\left(\n-\\frac{t_0 + x\\Delta t}{T}\n\\right),\n$$\n\nwhere $t_0$ is the elementary-link generation time, $x$ is the waiting count, $\\Delta t$ is the waiting interval, and $T$ is the memory coherence time.\n\n#### Teleportation fidelity\nSince $p_{\\mathrm{success}}$ already contains the path-level link-generation and swapping factors, the teleportation fidelity is evaluated as\n\n$$\nF = \\frac{1 + p_{\\mathrm{werner}}}{2}.\n$$\n')
elif model_type == 'Model 1':
    st.markdown('\n### Model 1 — Global Elementary Link Generation Model\n\nWe consider a quantum repeater network with $N$ nodes and adjacent-node spacing $L$.\n\n#### Elementary link generation\nThe success probability of generating one elementary link is taken as\n\n$$\np = \\eta_{d1}^{2}\\rho^{2}10^{-\\alpha L/10},\n$$\n\nwhere $\\eta_{d1}$ is the detector efficiency at the elementary-link stage, $\\rho$ is the entangled-pair generation probability, and $\\alpha$ is the fiber attenuation coefficient.\n\n#### Spectral multiplexing\nWith $m$ independent spectral modes, the effective elementary-link success probability becomes\n\n$$\np_{\\mathrm{elem}} = 1-(1-p)^m.\n$$\n\n#### Entanglement swapping\nFor a path containing $n$ elementary links, the swapping success probability is\n\n$$\np_{\\mathrm{swap}}\n=\n(\\eta_{\\mathrm{mem}}\\eta_{d2})^{2n},\n$$\n\nwhere $\\eta_{\\mathrm{mem}}$ is the memory efficiency and $\\eta_{d2}$ is the detector efficiency at the swapping stage.\n\n#### Total success probability\nIn Model 1, elementary-link generation is assumed over the **entire network**, so\n\n$$\np_{\\mathrm{success}}\n=\n(p_{\\mathrm{elem}})^{n_{\\mathrm{elem}}}p_{\\mathrm{swap}},\n$$\n\nwith\n\n$$\nn_{\\mathrm{elem}}=N-1.\n$$\n\n#### Decoherence model\nIncluding storage-induced decoherence, the Werner parameter is\n\n$$\np_{\\mathrm{werner}}\n=\np_{\\mathrm{success}}\n\\exp\\!\\left(\n-\\frac{t_0 + x\\Delta t}{T}\n\\right),\n$$\n\nwhere $t_0$ is the photon transmission time, $x$ is the waiting count, $\\Delta t$ is the waiting interval, and $T$ is the memory coherence time.\n\n#### Teleportation fidelity\nFor a path containing $n$ elementary links, the teleportation fidelity is\n\n$$\nF = \\frac{1 + (p_{\\mathrm{werner}})^n}{2}.\n$$\n')
else:
    st.markdown('\n### Model 2 — Path-Dependent Elementary Link Model\n\nModel 2 differs from Model 1 only in how the elementary-link contribution is accumulated.\n\n#### Elementary link generation\nThe probability of establishing one elementary link is\n\n$$\np = \\eta_{d1}^{2}\\rho^{2}10^{-\\alpha L/10}.\n$$\n\n#### Spectral multiplexing\nWith $m$ spectral modes,\n\n$$\np_{\\mathrm{elem}} = 1-(1-p)^m.\n$$\n\n#### Path-dependent total success probability\nFor a path containing $n$ elementary links,\n\n$$\np_{\\mathrm{success}}\n=\n(p_{\\mathrm{elem}})^n p_{\\mathrm{swap}},\n$$\n\nwhere\n\n$$\np_{\\mathrm{swap}}\n=\n(\\eta_{\\mathrm{mem}}\\eta_{d2})^{2n}.\n$$\n\n#### Decoherence model\nThe Werner parameter is\n\n$$\np_{\\mathrm{werner}}\n=\np_{\\mathrm{success}}\n\\exp\\!\\left(\n-\\frac{t_0 + x\\Delta t}{T}\n\\right).\n$$\n\n#### Teleportation fidelity\nThe resulting teleportation fidelity is\n\n$$\nF = \\frac{1 + p_{\\mathrm{werner}}}{2}.\n$$\n')

def create_chain(n):
    G = nx.Graph()
    for i in range(1, n):
        G.add_edge(i, i + 1)
    return G

def create_star(n):
    G = nx.Graph()
    center = 1
    for i in range(2, n + 1):
        G.add_edge(center, i)
    return G

def get_positions(graph, topology_name):
    if topology_name == 'chain':
        return {node: (idx, 0.0) for idx, node in enumerate(sorted(graph.nodes()), start=1)}
    return nx.spring_layout(graph, seed=7)

def draw_topology(graph, topology_name):
    fig, ax = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    pos = get_positions(graph, topology_name)
    nx.draw(graph, pos, with_labels=True, node_size=900, node_color=PHYSREV_TOPOLOGY_NODE, edge_color=PHYSREV_COLORS[0], width=2, font_size=11, ax=ax)
    topology_title = 'Intercity Network' if topology_name == 'chain' else 'Metropolitan Network'
    ax.set_title(topology_title)
    ax.axis('off')
    fig.tight_layout()
    return fig

def compute_t0_ms(distance_per_link_km, fiber_index_value):
    c = 300000000.0
    v = c / fiber_index_value
    d_m = distance_per_link_km * 1000.0
    photon_distance_m = d_m  # Outward photon travel plus return herald.
    return photon_distance_m / v * 1000.0

def get_all_paths(graph):
    pairs = list(itertools.combinations(sorted(graph.nodes()), 2))
    return [(u, v, nx.shortest_path(graph, u, v)) for u, v in pairs]

def memory_exposures(path_nodes, repeater_waits):
    """Pair-storage exposure in units of delta_t, excluding baseline storage.

    At a release boundary all ready swaps occur immediately, as in the
    manuscript example. Equal-time swaps add no artificial storage interval.
    """
    n = len(path_nodes) - 1
    if n <= 1:
        return (0, 0)
    max_exposure = n * max(repeater_waits.values(), default=0)
    segments = [(i, i + 1) for i in range(n)]
    exposure = 0
    previous_time = 0
    for time in sorted(set(repeater_waits.values())):
        exposure += len(segments) * (time - previous_time)
        for j in range(1, n):
            if repeater_waits[path_nodes[j]] != time:
                continue
            left = next((seg for seg in segments if seg[1] == j))
            right = next((seg for seg in segments if seg[0] == j))
            segments.remove(left)
            segments.remove(right)
            segments.append((left[0], right[1]))
        previous_time = time
    return (exposure, max_exposure)

def evaluate_order(ordered_paths, waiting_mode='Repeater-induced waiting'):
    node_wait = {}
    rows = []
    for idx, (u, v, p) in enumerate(ordered_paths, start=1):
        intermediate = p[1:-1]
        waits = []
        contrib = {}
        for node in intermediate:
            w = node_wait.get(node, 0)
            waits.append(w)
            contrib[node] = w
            node_wait[node] = w + 1
        max_wait = max(waits) if waits else 0
        ri_exposure, max_exposure = memory_exposures(p, contrib)
        selected_exposure = ri_exposure if waiting_mode == 'Repeater-induced waiting' else max_exposure
        rows.append({'order': idx, 'pair': (u, v), 'path_nodes': p, 'path': '->'.join(map(str, p)), 'links': len(p) - 1, 'waiting': max_wait, 'ri_exposure': ri_exposure, 'max_exposure': max_exposure, 'selected_exposure': selected_exposure, 'waiting_contribution': contrib})
    return rows

def compute_probabilities(n_links, m_value, n_nodes_value, distance_per_link_value, model_name, alpha_value=None, eta_d1_value=None, eta_d2_value=None, rho_value=None, eta_mem_value=None):
    _alpha = alpha_value if alpha_value is not None else alpha
    _eta_d1 = eta_d1_value if eta_d1_value is not None else eta_d1
    _eta_d2 = eta_d2_value if eta_d2_value is not None else eta_d2
    _rho = rho_value if rho_value is not None else rho
    _eta_mem = eta_mem_value if eta_mem_value is not None else eta_mem
    if model_name == 'Model 0':
        p_single = 1.0
        p_elem = 1.0
        p_swap = 1.0
        p_success = 1.0
        return (p_single, p_elem, p_swap, p_success)
    p_single = _eta_d1 ** 2 * _rho ** 2 * 10 ** (-_alpha * distance_per_link_value / 10)
    p_elem = 1 - (1 - p_single) ** m_value
    if n_links == 1:
        p_swap = 1.0
    else:
        p_swap = (_eta_mem * _eta_d2) ** (2 * (n_links - 1))
    if model_name == 'Model 1':
        n_elem = n_nodes_value - 1
        p_success = p_elem ** n_elem * p_swap
    else:
        p_success = p_elem ** n_links * p_swap
    return (p_single, p_elem, p_swap, p_success)

def compute_fidelity(p_success, n_links, waiting, delta_t_unit_value, t0_ms, T_ms, model_name):
    delta_t_ms = waiting * delta_t_unit_value
    exponent_component = (n_links * t0_ms + delta_t_ms) / T_ms
    exp_term = math.exp(-exponent_component)
    p_werner = p_success * exp_term
    fidelity = (1 + p_werner) / 2
    return (fidelity, delta_t_ms, exponent_component, exp_term, p_werner)

def make_table(order_rows, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, t0_value, T_value, model_name, alpha_value=None, eta_d1_value=None, eta_d2_value=None, rho_value=None, eta_mem_value=None, waiting_mode='Repeater-induced waiting'):
    final_rows = []
    for r in order_rows:
        p_single, p_elem, p_swap, p_success = compute_probabilities(r['links'], m_value, n_nodes_value, distance_per_link_value, model_name, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value)
        fidelity, delta_t_ms, exponent_component, exp_term, p_werner = compute_fidelity(p_success=p_success, n_links=r['links'], waiting=r['selected_exposure'], delta_t_unit_value=delta_t_unit_value, t0_ms=t0_value, T_ms=T_value, model_name=model_name)
        final_rows.append({'m': m_value, 'order': r['order'], 'pair': str(r['pair']), 'path': r['path'], 'links': r['links'], 'waiting': r['waiting'], 'ri_exposure_intervals': r['ri_exposure'], 'max_exposure_intervals': r['max_exposure'], 'ri_exposure_ms': r['ri_exposure'] * delta_t_unit_value, 'max_exposure_ms': r['max_exposure'] * delta_t_unit_value, 'waiting_contribution': str(r['waiting_contribution']), 't0_ms': t0_value, 'delta_t_ms': delta_t_ms, 't0_plus_delta_over_T': exponent_component, 'exp_term': exp_term, 'p_single': p_single, 'p_elem': p_elem, 'p_swap': p_swap, 'p_success': p_success, 'p_werner': p_werner, 'fidelity': fidelity, 'raw_path_nodes': r['path_nodes']})
    return pd.DataFrame(final_rows)

def split_zero_and_conflict_paths(paths):
    zero_wait = []
    conflict = []
    for item in paths:
        _, _, p = item
        if len(p) <= 2:
            zero_wait.append(item)
        else:
            conflict.append(item)
    zero_wait = tuple(sorted(zero_wait, key=lambda x: (x[0], x[1])))
    conflict = tuple(sorted(conflict, key=lambda x: (x[0], x[1])))
    return (zero_wait, conflict)

def build_reduced_orders(paths, max_exact, sample_count, seed):
    zero_wait, conflict = split_zero_and_conflict_paths(paths)
    n_conflict = len(conflict)
    total_exact = math.factorial(n_conflict)
    if total_exact <= max_exact:
        orders = [list(zero_wait) + list(perm) for perm in itertools.permutations(conflict)]
        return (orders, 'exact_reduced', len(zero_wait), len(conflict))
    rng = random.Random(seed)
    seen = set()
    sampled = []
    base = tuple((c[0] for c in conflict))
    rev = tuple((c[0] for c in reversed(conflict)))
    for key, cand in [(base, list(conflict)), (rev, list(reversed(conflict)))]:
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + cand)
    attempts = 0
    max_attempts = sample_count * 20
    while len(sampled) < sample_count and attempts < max_attempts:
        attempts += 1
        arr = list(conflict)
        rng.shuffle(arr)
        key = tuple((c[0] for c in arr))
        if key not in seen:
            seen.add(key)
            sampled.append(list(zero_wait) + arr)
    return (sampled, f'sampled_reduced_{len(sampled)}', len(zero_wait), len(conflict))

@st.cache_data(show_spinner=False)
def quantum_advantage_zone_cached(topology_name, model_name, link_distance_tuple, delta_tuple, m_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """
    Fixed 5-node quantum advantage map for the selected model.
    Sweeps:
      - distance per adjacent link
      - delta_t_unit
    Checks whether average fidelity exceeds 2/3.
    """
    n_nodes_fixed = 5
    threshold = 2.0 / 3.0
    fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)))
    adv_fmax_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)
    adv_fmin_grid = np.zeros((len(delta_tuple), len(link_distance_tuple)), dtype=int)
    for i, dt in enumerate(delta_tuple):
        for j, d_link in enumerate(link_distance_tuple):
            res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_fixed, m_value=m_value, distance_per_link_value=float(d_link), delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
            if topology_name == 'star':
                favg = res['favg']
                fmax_grid[i, j] = favg
                fmin_grid[i, j] = favg
                adv_fmax_grid[i, j] = 1 if favg > threshold else 0
                adv_fmin_grid[i, j] = 1 if favg > threshold else 0
            else:
                fmax_grid[i, j] = res['fmax']
                fmin_grid[i, j] = res['fmin']
                adv_fmax_grid[i, j] = 1 if res['fmax'] > threshold else 0
                adv_fmin_grid[i, j] = 1 if res['fmin'] > threshold else 0
    return (fmax_grid, fmin_grid, adv_fmax_grid, adv_fmin_grid)

@st.cache_data(show_spinner=False)
def quantum_advantage_modes_delta_cached(topology_name, model_name, modes_tuple, delta_tuple, n_nodes_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """
    Quantum advantage map for fixed current network parameters.
    Sweeps:
      - multiplexing modes m
      - delta_t_unit
    Checks whether average fidelity exceeds 2/3.
    """
    threshold = 2.0 / 3.0
    fmax_grid = np.zeros((len(delta_tuple), len(modes_tuple)))
    fmin_grid = np.zeros((len(delta_tuple), len(modes_tuple)))
    adv_fmax_grid = np.zeros((len(delta_tuple), len(modes_tuple)), dtype=int)
    adv_fmin_grid = np.zeros((len(delta_tuple), len(modes_tuple)), dtype=int)
    for i, dt in enumerate(delta_tuple):
        for j, mm in enumerate(modes_tuple):
            res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_value, m_value=int(mm), distance_per_link_value=distance_per_link_value, delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
            if topology_name == 'star':
                favg = res['favg']
                fmax_grid[i, j] = favg
                fmin_grid[i, j] = favg
                adv_fmax_grid[i, j] = 1 if favg > threshold else 0
                adv_fmin_grid[i, j] = 1 if favg > threshold else 0
            else:
                fmax_grid[i, j] = res['fmax']
                fmin_grid[i, j] = res['fmin']
                adv_fmax_grid[i, j] = 1 if res['fmax'] > threshold else 0
                adv_fmin_grid[i, j] = 1 if res['fmin'] > threshold else 0
    return (fmax_grid, fmin_grid, adv_fmax_grid, adv_fmin_grid)

@st.cache_data(show_spinner=False)
def quantum_advantage_4d_cached(topology_name, model_name, distance_tuple, delta_tuple, modes_tuple, n_nodes_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    threshold = 2.0 / 3.0
    rows = []
    for mm in modes_tuple:
        for dt in delta_tuple:
            for d_link in distance_tuple:
                res = evaluate_topology_for_one_delta_cached(topology_name=topology_name, n_nodes_value=n_nodes_value, m_value=int(mm), distance_per_link_value=float(d_link), delta_t_unit_value=float(dt), T_value=T_value, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, fiber_index_value=fiber_index_value, model_name=model_name, max_exact=max_exact, sample_count=sample_count, seed=seed, waiting_mode=waiting_mode)
                if topology_name == 'star':
                    fmax = res['favg']
                    fmin = res['favg']
                else:
                    fmax = res['fmax']
                    fmin = res['fmin']
                rows.append({'distance_km': float(d_link), 'delta_t_ms': float(dt), 'modes': int(mm), 'log10_modes': math.log10(int(mm)), 'fmax': float(fmax), 'fmin': float(fmin), 'adv_fmax': 1 if fmax > threshold else 0, 'adv_fmin': 1 if fmin > threshold else 0})
    return pd.DataFrame(rows)

def evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    graph = create_chain(n_nodes_value) if topology_name == 'chain' else create_star(n_nodes_value)
    paths = get_all_paths(graph)
    orders, eval_mode, zero_count, conflict_count = build_reduced_orders(paths, int(max_exact), int(sample_count), int(seed))
    t0_value = compute_t0_ms(distance_per_link_value, fiber_index_value)
    all_avgF = []
    all_tables = []
    for order in orders:
        rows = evaluate_order(order, waiting_mode=waiting_mode)
        df = make_table(rows, n_nodes_value, m_value, distance_per_link_value, delta_t_unit_value, t0_value, T_value, model_name, alpha_value=alpha_value, eta_d1_value=eta_d1_value, eta_d2_value=eta_d2_value, rho_value=rho_value, eta_mem_value=eta_mem_value, waiting_mode=waiting_mode)
        avgF = float(df['fidelity'].mean())
        all_avgF.append(avgF)
        all_tables.append(df)
    if topology_name == 'star':
        avg_val = float(np.mean(all_avgF))
        avg_df = all_tables[int(np.argmax(all_avgF))]
        return {'favg': avg_val, 'fmax': avg_val, 'fmin': avg_val, 'best_df': avg_df, 'worst_df': avg_df, 'eval_mode': 'single_average_star', 'orders_evaluated': len(all_avgF), 'zero_paths': zero_count, 'conflict_paths': conflict_count}
    best_idx = int(np.argmax(all_avgF))
    worst_idx = int(np.argmin(all_avgF))
    return {'fmax': all_avgF[best_idx], 'fmin': all_avgF[worst_idx], 'best_df': all_tables[best_idx], 'worst_df': all_tables[worst_idx], 'eval_mode': eval_mode, 'orders_evaluated': len(orders), 'zero_paths': zero_count, 'conflict_paths': conflict_count}

@st.cache_data(show_spinner=False)
def modes_sweep_cached(topology_name, modes_tuple, n_nodes_value, distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    best_vals = []
    worst_vals = []
    for mm in modes_tuple:
        res = evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, int(mm), distance_per_link_value, delta_t_unit_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        best_vals.append(res['fmax'])
        worst_vals.append(res['fmin'])
    return (best_vals, worst_vals)

@st.cache_data(show_spinner=False)
def delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    best_vals = []
    worst_vals = []
    for dt in deltas_tuple:
        res = evaluate_topology_for_one_delta_cached(topology_name, n_nodes_value, m_value, distance_per_link_value, float(dt), T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        best_vals.append(res['fmax'])
        worst_vals.append(res['fmin'])
    return (best_vals, worst_vals)

@st.cache_data(show_spinner=False)
def multi_node_delta_sweep_cached(node_counts_tuple, deltas_tuple, m_value, total_distance_value, fixed_distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """For each node count, compute star average fidelity across delta_t values."""
    results = {}
    for n in node_counts_tuple:
        if fixed_distance_per_link_value is None:
            dist_per_link = total_distance_value / (n - 1)
        else:
            dist_per_link = fixed_distance_per_link_value
        star_vals, _ = delta_sweep_cached('star', deltas_tuple, n, m_value, dist_per_link, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, model_name, max_exact, sample_count, seed, waiting_mode=waiting_mode)
        results[n] = star_vals
    return results

@st.cache_data(show_spinner=False)
def model_comparison_delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, max_exact, sample_count, seed, waiting_mode='Repeater-induced waiting'):
    _timing_convention = 'full-link-heralding-L-over-v'
    """Compute delta sweep for Model 0, Model 1, and Model 2 for comparison."""
    best_m0, worst_m0 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 0', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    best_m1, worst_m1 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 1', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    best_m2, worst_m2 = delta_sweep_cached(topology_name, deltas_tuple, n_nodes_value, m_value, distance_per_link_value, T_value, alpha_value, eta_d1_value, eta_d2_value, rho_value, eta_mem_value, fiber_index_value, 'Model 2', max_exact, sample_count, seed, waiting_mode=waiting_mode)
    return (best_m0, worst_m0, best_m1, worst_m1, best_m2, worst_m2)

def make_excel_bytes(sheets_dict):
    output = io.BytesIO()
    try:
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            for sheet_name, df in sheets_dict.items():
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        output.seek(0)
        return output.getvalue()
    except Exception:
        return None

def representative_path_links(topology_name, n_nodes_value):
    if topology_name == 'chain':
        return n_nodes_value - 1
    else:
        return 2 if n_nodes_value > 2 else 1
t0 = compute_t0_ms(distance_per_link, fiber_index)
chain_graph = create_chain(n_nodes)
star_graph = create_star(n_nodes)
if network_type == 'Intercity (Chain)':
    st.pyplot(draw_topology(chain_graph, 'chain'), clear_figure=True)
else:
    st.pyplot(draw_topology(star_graph, 'star'), clear_figure=True)
if network_type == 'Intercity (Chain)':
    chain_res = evaluate_topology_for_one_delta_cached('chain', n_nodes, m, distance_per_link, delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    chain_fmax = chain_res['fmax']
    chain_fmin = chain_res['fmin']
    chain_df_max = chain_res['best_df']
    chain_df_min = chain_res['worst_df']
else:
    star_res = evaluate_topology_for_one_delta_cached('star', n_nodes, m, distance_per_link, delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    star_avg = star_res['favg']
    star_df = star_res['best_df']
st.subheader('Core Results')
p_single_now, p_elem_now, _, _ = compute_probabilities(1, m, n_nodes, distance_per_link, model_type)
if network_type == 'Intercity (Chain)':
    c1, c2, c3 = st.columns(3)
    c1.metric('Intercity Network Fmax', f'{chain_fmax:.6f}')
    c2.metric('Intercity Network Fmin', f'{chain_fmin:.6f}')
    c3.metric('t0 (ms)', f'{t0:.6f}')
    st.write({'model': model_type, 'network_type': network_type, 'chain_eval_mode': chain_res['eval_mode'], 'chain_orders_evaluated': chain_res['orders_evaluated'], 'chain_zero_paths': chain_res['zero_paths'], 'chain_conflict_paths': chain_res['conflict_paths'], 'adjacent_link_p_single': p_single_now, 'adjacent_link_p_elem': p_elem_now})
else:
    c1, c2 = st.columns(2)
    c1.metric('Metropolitan Network Fidelity', f'{star_avg:.6f}')
    c2.metric('t0 (ms)', f'{t0:.6f}')
    st.write({'model': model_type, 'network_type': network_type, 'star_eval_mode': star_res['eval_mode'], 'star_orders_evaluated': star_res['orders_evaluated'], 'adjacent_link_p_single': p_single_now, 'adjacent_link_p_elem': p_elem_now})
fig_bar, ax_bar = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
if network_type == 'Intercity (Chain)':
    ax_bar.bar(['Intercity Network Fmax', 'Intercity Network Fmin'], [chain_fmax, chain_fmin], color=[COLOR_CHAIN_MAX, COLOR_CHAIN_MIN])
    ax_bar.set_title('Intercity Network: fidelity summary')
else:
    ax_bar.bar(['Metropolitan Network'], [star_avg], color=[COLOR_STAR])
    ax_bar.set_title('Metropolitan Network: fidelity summary')
ax_bar.set_ylabel('Average Fidelity')
apply_normal_axis_format(ax_bar)
st.pyplot(fig_bar, clear_figure=True)
st.subheader(f'{model_type} — Average Fidelity vs Modes')
st.caption(f'Δt fixed at {delta_t_unit} ms (sidebar value)')
if network_type == 'Intercity (Chain)':
    chain_modes_best, chain_modes_worst = modes_sweep_cached('chain', tuple(mode_values), n_nodes, distance_per_link, delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    fig_modes, ax_modes = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_modes.plot(mode_values, chain_modes_best, marker='o', color=COLOR_CHAIN_MAX, linestyle='-', label='Intercity Network $F_{\\max}^{\\rm avg}$')
    ax_modes.plot(mode_values, chain_modes_worst, marker='s', color=COLOR_CHAIN_MIN, linestyle='--', label='Intercity Network $F_{\\min}^{\\rm avg}$')
    ax_modes.set_xlabel('Multiplexing modes, $m$')
    ax_modes.set_ylabel('Average Fidelity')
    ax_modes.set_title(f'{model_type}: Intercity Network')
    physrev_legend(ax_modes)
    apply_normal_axis_format(ax_modes)
    st.pyplot(fig_modes, clear_figure=True)
    df_modes = pd.DataFrame({'Modes': mode_values, 'Intercity_Network_Fmax': chain_modes_best, 'Intercity_Network_Fmin': chain_modes_worst})
else:
    star_modes_best, _ = modes_sweep_cached('star', tuple(mode_values), n_nodes, distance_per_link, delta_t_unit, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    fig_modes, ax_modes = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_modes.plot(mode_values, star_modes_best, marker='o', color=COLOR_STAR, linestyle='-', label='Metropolitan Network $F^{\\rm avg}$')
    ax_modes.set_xlabel('Multiplexing modes, $m$')
    ax_modes.set_ylabel('Average Fidelity')
    ax_modes.set_title(f'{model_type}: Metropolitan Network')
    physrev_legend(ax_modes)
    apply_normal_axis_format(ax_modes)
    st.pyplot(fig_modes, clear_figure=True)
    df_modes = pd.DataFrame({'Modes': mode_values, 'Metropolitan_Network_Favg': star_modes_best})
st.dataframe(df_modes, use_container_width=True)
st.download_button(f'Download {model_type} Modes Data (CSV)', df_modes.to_csv(index=False).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_fidelity_modes.csv", 'text/csv')
st.subheader('Average Fidelity vs Δt')
if network_type == 'Intercity (Chain)':
    chain_delta_best, chain_delta_worst = delta_sweep_cached('chain', tuple(map(float, delta_values)), n_nodes, m, distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    fig_delta, ax_delta = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_delta.plot(delta_values, chain_delta_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Intercity Network $F_{\\max}^{\\rm avg}$')
    ax_delta.plot(delta_values, chain_delta_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Intercity Network $F_{\\min}^{\\rm avg}$')
    ax_delta.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_delta.set_ylabel('Average Fidelity')
    ax_delta.set_title('Intercity Network')
    physrev_legend(ax_delta)
    apply_normal_axis_format(ax_delta)
    st.pyplot(fig_delta, clear_figure=True)
    df_delta = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'Intercity_Network_Fmax': chain_delta_best, 'Intercity_Network_Fmin': chain_delta_worst})
else:
    star_delta_best, _ = delta_sweep_cached('star', tuple(map(float, delta_values)), n_nodes, m, distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    fig_delta, ax_delta = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_delta.plot(delta_values, star_delta_best, color=COLOR_STAR, linestyle='-', label='Metropolitan Network $F^{\\rm avg}$')
    ax_delta.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_delta.set_ylabel('Average Fidelity')
    ax_delta.set_title('Metropolitan Network')
    physrev_legend(ax_delta)
    apply_normal_axis_format(ax_delta)
    st.pyplot(fig_delta, clear_figure=True)
    df_delta = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'Metropolitan_Network': star_delta_best})
st.dataframe(df_delta, use_container_width=True)
st.download_button('Download Delta Data (CSV)', df_delta.to_csv(index=False).encode('utf-8'), 'fidelity_delta.csv', 'text/csv')
st.subheader('Detailed Tables')
if network_type == 'Intercity (Chain)':
    tab1, tab2 = st.tabs(['Intercity Network Fmax', 'Intercity Network Fmin'])
    with tab1:
        show_df = chain_df_max.drop(columns=['raw_path_nodes'])
        st.dataframe(show_df, use_container_width=True)
        st.download_button('Download Intercity Network Fmax Table', show_df.to_csv(index=False).encode('utf-8'), 'chain_fmax_table.csv', 'text/csv', key='fmax_csv')
    with tab2:
        show_df = chain_df_min.drop(columns=['raw_path_nodes'])
        st.dataframe(show_df, use_container_width=True)
        st.download_button('Download Intercity Network Fmin Table', show_df.to_csv(index=False).encode('utf-8'), 'chain_fmin_table.csv', 'text/csv', key='fmin_csv')
else:
    show_df = star_df.drop(columns=['raw_path_nodes'])
    st.dataframe(show_df, use_container_width=True)
    st.download_button('Download Metropolitan Network Table', show_df.to_csv(index=False).encode('utf-8'), 'metropolitan_network_table.csv', 'text/csv', key='star_csv')
st.subheader(f'{model_type} — Average Fidelity vs Δt (Using m = {int(m_comparison)})')
st.caption('This is an additional selected-model view using the fixed m value from the sidebar.')
if network_type == 'Intercity (Chain)':
    cmp_best, cmp_worst = delta_sweep_cached('chain', tuple(map(float, delta_values)), n_nodes, int(m_comparison), distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    df_cmp = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'Intercity_Network_Fmax': cmp_best, 'Intercity_Network_Fmin': cmp_worst})
    fig_cmp, ax_cmp = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_cmp.plot(delta_values, cmp_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Intercity Network $F_{\\max}^{\\rm avg}$')
    ax_cmp.plot(delta_values, cmp_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Intercity Network $F_{\\min}^{\\rm avg}$')
    ax_cmp.set_title(f'{model_type}: Intercity Network, $m={int(m_comparison)}$')
    ax_cmp.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_cmp.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp)
    apply_normal_axis_format(ax_cmp)
    st.pyplot(fig_cmp, clear_figure=True)
else:
    cmp_best, _ = delta_sweep_cached('star', tuple(map(float, delta_values)), n_nodes, int(m_comparison), distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    df_cmp = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'Metropolitan_Network_Favg': cmp_best})
    fig_cmp, ax_cmp = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    ax_cmp.plot(delta_values, cmp_best, color=COLOR_STAR, linestyle='-', label='Metropolitan Network $F^{\\rm avg}$')
    ax_cmp.set_title(f'{model_type}: Metropolitan Network, $m={int(m_comparison)}$')
    ax_cmp.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_cmp.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp)
    apply_normal_axis_format(ax_cmp)
    st.pyplot(fig_cmp, clear_figure=True)
st.dataframe(df_cmp, use_container_width=True)
st.download_button(f'Download {model_type} Fixed-m Delta Data (CSV)', df_cmp.to_csv(index=False).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_fixed_m_delta.csv", 'text/csv')
st.subheader(f'{model_type} — Quantum Advantage Zone (Fixed 5 Nodes)')
if network_type == 'Intracity (Star)':
    st.caption('This figure is generated for a fixed 5-node Metropolitan Network. For quantum-advantage visualization, adjacent-link distance and Δt are swept using the selected step sizes. Quantum advantage is defined by F > 2/3.')
else:
    st.caption('This figure is generated for a fixed 5-node network for the currently selected model and topology. The swept parameters are adjacent-link distance and Δt using the selected step sizes. Quantum advantage is defined by F > 2/3.')
qa_link_distance_values = stepped_values(qa_link_distance_min, qa_link_distance_max, qa_link_distance_step)
qa_delta_values = stepped_values(qa_delta_t_min, qa_delta_t_max, qa_delta_t_step)
qa_topology_name = 'chain' if network_type == 'Intercity (Chain)' else 'star'
qa_fmax_grid, qa_fmin_grid, qa_adv_fmax_grid, qa_adv_fmin_grid = quantum_advantage_zone_cached(topology_name=qa_topology_name, model_name=model_type, link_distance_tuple=tuple(map(float, qa_link_distance_values)), delta_tuple=tuple(map(float, qa_delta_values)), m_value=m, T_value=T, alpha_value=alpha, eta_d1_value=eta_d1, eta_d2_value=eta_d2, rho_value=rho, eta_mem_value=eta_mem, fiber_index_value=fiber_index, max_exact=int(max_exact_orders), sample_count=int(sample_orders), seed=int(random_seed), waiting_mode=waiting_mode)
if network_type == 'Intercity (Chain)':
    st.markdown(f'#### {model_type} — Intercity Network Quantum Advantage Surface using $F_{{max}}^{{avg}}$')
    fig_qa_fmax, ax_qa1 = make_3d_figure()
    plot_threshold_surface_3d(ax_qa1, qa_link_distance_values, qa_delta_values, qa_fmax_grid, f'{model_type} — Intercity Network Quantum Advantage Surface using $F_{{max}}^{{avg}}$', '$F_{max}^{avg}$')
    st.pyplot(fig_qa_fmax, clear_figure=True)
    st.markdown(f'#### {model_type} — Intercity Network Quantum Advantage Heatmap using $F_{{max}}^{{avg}}$')
    fig_qa_fmax_heat, ax_qa_fmax_heat = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_quantum_advantage_heatmap(ax_qa_fmax_heat, qa_link_distance_values, qa_delta_values, qa_fmax_grid, f'{model_type}: Intercity Network heatmap using $F_{{max}}^{{avg}}$', '$F_{max}^{avg}$')
    st.pyplot(fig_qa_fmax_heat, clear_figure=True)
    st.markdown(f'#### {model_type} — Intercity Network Quantum Advantage Surface using $F_{{min}}^{{avg}}$')
    fig_qa_fmin, ax_qa2 = make_3d_figure()
    plot_threshold_surface_3d(ax_qa2, qa_link_distance_values, qa_delta_values, qa_fmin_grid, f'{model_type} — Intercity Network Quantum Advantage Surface using $F_{{min}}^{{avg}}$', '$F_{min}^{avg}$')
    st.pyplot(fig_qa_fmin, clear_figure=True)
    st.markdown(f'#### {model_type} — Intercity Network Quantum Advantage Heatmap using $F_{{min}}^{{avg}}$')
    fig_qa_fmin_heat, ax_qa_fmin_heat = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_quantum_advantage_heatmap(ax_qa_fmin_heat, qa_link_distance_values, qa_delta_values, qa_fmin_grid, f'{model_type}: Intercity Network heatmap using $F_{{min}}^{{avg}}$', '$F_{min}^{avg}$')
    st.pyplot(fig_qa_fmin_heat, clear_figure=True)
    qa_df_fmax = pd.DataFrame(qa_fmax_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    qa_df_fmin = pd.DataFrame(qa_fmin_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    qa_df_adv_fmax = pd.DataFrame(qa_adv_fmax_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    qa_df_adv_fmin = pd.DataFrame(qa_adv_fmin_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    st.markdown(f'#### {model_type} — Intercity Network $F_{{max}}^{{avg}}$ Values')
    st.dataframe(qa_df_fmax, use_container_width=True)
    st.markdown(f'#### {model_type} — Intercity Network $F_{{min}}^{{avg}}$ Values')
    st.dataframe(qa_df_fmin, use_container_width=True)
    st.markdown(f'#### {model_type} — Intercity Network Advantage Map using $F_{{max}}^{{avg}}$')
    st.dataframe(qa_df_adv_fmax, use_container_width=True)
    st.markdown(f'#### {model_type} — Intercity Network Advantage Map using $F_{{min}}^{{avg}}$')
    st.dataframe(qa_df_adv_fmin, use_container_width=True)
    st.download_button(f'Download {model_type} Intercity Network Fmax^avg Grid (CSV)', qa_df_fmax.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_fmax_avg_grid.csv", 'text/csv', key='model0_chain_fmax_avg_grid_csv')
    st.download_button(f'Download {model_type} Intercity Network Fmin^avg Grid (CSV)', qa_df_fmin.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_fmin_avg_grid.csv", 'text/csv', key='model0_chain_fmin_avg_grid_csv')
    st.download_button(f'Download {model_type} Intercity Network Advantage Fmax^avg Map (CSV)', qa_df_adv_fmax.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_adv_fmax_avg_map.csv", 'text/csv', key='model0_chain_adv_fmax_avg_map_csv')
    st.download_button(f'Download {model_type} Intercity Network Advantage Fmin^avg Map (CSV)', qa_df_adv_fmin.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_adv_fmin_avg_map.csv", 'text/csv', key='model0_chain_adv_fmin_avg_map_csv')
else:
    fig_qa, ax_qa = make_3d_figure()
    plot_threshold_surface_3d(ax_qa, qa_link_distance_values, qa_delta_values, qa_fmax_grid, f'{model_type} — Metropolitan Network Quantum Advantage Surface using $F^{{avg}}$', '$F^{avg}$')
    st.pyplot(fig_qa, clear_figure=True)
    st.markdown(f'#### {model_type} — Metropolitan Network Quantum Advantage Heatmap using $F^{{avg}}$')
    fig_qa_heat, ax_qa_heat = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_quantum_advantage_heatmap(ax_qa_heat, qa_link_distance_values, qa_delta_values, qa_fmax_grid, f'{model_type}: Metropolitan Network heatmap using $F^{{avg}}$', '$F^{avg}$')
    st.pyplot(fig_qa_heat, clear_figure=True)
    qa_df_favg = pd.DataFrame(qa_fmax_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    qa_df_adv_favg = pd.DataFrame(qa_adv_fmax_grid, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    st.markdown(f'#### {model_type} — Metropolitan Network $F^{{avg}}$ Values')
    st.dataframe(qa_df_favg, use_container_width=True)
    st.markdown(f'#### {model_type} — Metropolitan Network Advantage Map using $F^{{avg}}$')
    st.dataframe(qa_df_adv_favg, use_container_width=True)
    st.download_button(f'Download {model_type} Metropolitan Network Favg Grid (CSV)', qa_df_favg.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_star_favg_grid.csv", 'text/csv', key='model0_star_favg_grid_csv')
    st.download_button(f'Download {model_type} Metropolitan Network Advantage Map (CSV)', qa_df_adv_favg.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_star_adv_map.csv", 'text/csv', key='model0_star_adv_map_csv')
st.subheader(f'{model_type} — Quantum Advantage Map vs Modes and Δt')
st.caption('This map keeps the current network parameters fixed, including node count, total distance, link distance, efficiencies, and coherence time. It sweeps multiplexing modes m and Δt to show where the selected model achieves F > 2/3.')
qa_mode_values = np.unique(np.round(np.logspace(math.log10(int(qa_modes_min)), math.log10(int(qa_modes_max)), int(qa_modes_points))).astype(int))
qa_mode_values = qa_mode_values[qa_mode_values >= 1]
qa_modes_fmax_grid, qa_modes_fmin_grid, qa_modes_adv_fmax_grid, qa_modes_adv_fmin_grid = quantum_advantage_modes_delta_cached(topology_name=qa_topology_name, model_name=model_type, modes_tuple=tuple(map(int, qa_mode_values)), delta_tuple=tuple(map(float, qa_delta_values)), n_nodes_value=n_nodes, distance_per_link_value=distance_per_link, T_value=T, alpha_value=alpha, eta_d1_value=eta_d1, eta_d2_value=eta_d2, rho_value=rho, eta_mem_value=eta_mem, fiber_index_value=fiber_index, max_exact=int(max_exact_orders), sample_count=int(sample_orders), seed=int(random_seed), waiting_mode=waiting_mode)
if network_type == 'Intercity (Chain)':
    st.markdown(f'#### {model_type} — Intercity Network 3D Map using $F_{{max}}^{{avg}}$')
    fig_modes_qa_fmax, ax_modes_qa_fmax = make_3d_figure()
    plot_modes_delta_surface_3d(ax_modes_qa_fmax, qa_mode_values, qa_delta_values, qa_modes_fmax_grid, f'{model_type} — Intercity Network QA map using $F_{{max}}^{{avg}}$', '$F_{max}^{avg}$')
    st.pyplot(fig_modes_qa_fmax, clear_figure=True)
    st.markdown(f'#### {model_type} — Intercity Network 3D Map using $F_{{min}}^{{avg}}$')
    fig_modes_qa_fmin, ax_modes_qa_fmin = make_3d_figure()
    plot_modes_delta_surface_3d(ax_modes_qa_fmin, qa_mode_values, qa_delta_values, qa_modes_fmin_grid, f'{model_type} — Intercity Network QA map using $F_{{min}}^{{avg}}$', '$F_{min}^{avg}$')
    st.pyplot(fig_modes_qa_fmin, clear_figure=True)
    qa_modes_df_fmax = pd.DataFrame(qa_modes_fmax_grid, index=np.round(qa_delta_values, 4), columns=qa_mode_values)
    qa_modes_df_fmin = pd.DataFrame(qa_modes_fmin_grid, index=np.round(qa_delta_values, 4), columns=qa_mode_values)
    st.download_button(f'Download {model_type} Intercity Network Modes-vs-Delta Fmax Grid (CSV)', qa_modes_df_fmax.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_modes_delta_fmax_grid.csv", 'text/csv')
    st.download_button(f'Download {model_type} Intercity Network Modes-vs-Delta Fmin Grid (CSV)', qa_modes_df_fmin.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_chain_modes_delta_fmin_grid.csv", 'text/csv')
else:
    st.markdown(f'#### {model_type} — Metropolitan Network 3D Map using $F^{{avg}}$')
    fig_modes_qa, ax_modes_qa = make_3d_figure()
    plot_modes_delta_surface_3d(ax_modes_qa, qa_mode_values, qa_delta_values, qa_modes_fmax_grid, f'{model_type} — Metropolitan Network QA map using $F^{{avg}}$', '$F^{avg}$')
    st.pyplot(fig_modes_qa, clear_figure=True)
    qa_modes_df_favg = pd.DataFrame(qa_modes_fmax_grid, index=np.round(qa_delta_values, 4), columns=qa_mode_values)
    st.download_button(f'Download {model_type} Metropolitan Network Modes-vs-Delta Favg Grid (CSV)', qa_modes_df_favg.to_csv(index=True).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_star_modes_delta_favg_grid.csv", 'text/csv')
st.subheader(f'{model_type} — 4D Quantum Advantage Zone')
if network_type == 'Intracity (Star)':
    st.caption('This static slice map sweeps Metropolitan Network adjacent-link distance and waiting interval Δt using the selected step sizes, while also sweeping multiplexing modes m. Each panel fixes one value of m. The dashed contour marks F = 2/3.')
else:
    st.caption('This static slice map sweeps adjacent-link distance, waiting interval Δt, and multiplexing modes m. Each panel fixes one value of m and shows fidelity over the distance–Δt plane. The dashed contour marks F = 2/3.')
qa_4d_distance_values = stepped_values(qa_link_distance_min, qa_link_distance_max, qa_link_distance_step)
qa_4d_delta_values = stepped_values(qa_delta_t_min, qa_delta_t_max, qa_delta_t_step)
qa_4d_df = quantum_advantage_4d_cached(topology_name=qa_topology_name, model_name=model_type, distance_tuple=tuple(map(float, qa_4d_distance_values)), delta_tuple=tuple(map(float, qa_4d_delta_values)), modes_tuple=tuple(map(int, qa_4d_mode_values)), n_nodes_value=n_nodes, T_value=T, alpha_value=alpha, eta_d1_value=eta_d1, eta_d2_value=eta_d2, rho_value=rho, eta_mem_value=eta_mem, fiber_index_value=fiber_index, max_exact=int(max_exact_orders), sample_count=int(sample_orders), seed=int(random_seed), waiting_mode=waiting_mode)
if network_type == 'Intercity (Chain)':
    fig_4d_fmax = plot_4d_mode_slices(qa_4d_df, qa_4d_mode_values, 'fmax', f'{model_type}: Intercity Network 4D advantage zone using $F_{{max}}^{{avg}}$', '$F_{max}^{avg}$')
    st.pyplot(fig_4d_fmax, clear_figure=True)
    fig_4d_fmin = plot_4d_mode_slices(qa_4d_df, qa_4d_mode_values, 'fmin', f'{model_type}: Intercity Network 4D advantage zone using $F_{{min}}^{{avg}}$', '$F_{min}^{avg}$')
    st.pyplot(fig_4d_fmin, clear_figure=True)
else:
    fig_4d_favg = plot_4d_mode_slices(qa_4d_df, qa_4d_mode_values, 'fmax', f'{model_type}: Metropolitan Network 4D advantage zone using $F^{{avg}}$', '$F^{avg}$')
    st.pyplot(fig_4d_favg, clear_figure=True)
st.download_button(f'Download {model_type} 4D Quantum Advantage Data (CSV)', qa_4d_df.drop(columns=['log10_modes']).to_csv(index=False).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_{qa_topology_name}_4d_quantum_advantage.csv", 'text/csv')
st.subheader('Model 1 vs Model 2 — Quantum Advantage Difference')
st.caption('These heatmaps use the same fixed 5-node sweep as the quantum-advantage plots above. The difference map shows ΔF = F_Model2 − F_Model1. Positive values indicate that Model 2 gives higher average fidelity. The gain map highlights parameter regions where Model 2 reaches F > 2/3 while Model 1 does not.')
qa_m1_fmax, qa_m1_fmin, qa_m1_adv_fmax, qa_m1_adv_fmin = quantum_advantage_zone_cached(topology_name=qa_topology_name, model_name='Model 1', link_distance_tuple=tuple(map(float, qa_link_distance_values)), delta_tuple=tuple(map(float, qa_delta_values)), m_value=m, T_value=T, alpha_value=alpha, eta_d1_value=eta_d1, eta_d2_value=eta_d2, rho_value=rho, eta_mem_value=eta_mem, fiber_index_value=fiber_index, max_exact=int(max_exact_orders), sample_count=int(sample_orders), seed=int(random_seed), waiting_mode=waiting_mode)
qa_m2_fmax, qa_m2_fmin, qa_m2_adv_fmax, qa_m2_adv_fmin = quantum_advantage_zone_cached(topology_name=qa_topology_name, model_name='Model 2', link_distance_tuple=tuple(map(float, qa_link_distance_values)), delta_tuple=tuple(map(float, qa_delta_values)), m_value=m, T_value=T, alpha_value=alpha, eta_d1_value=eta_d1, eta_d2_value=eta_d2, rho_value=rho, eta_mem_value=eta_mem, fiber_index_value=fiber_index, max_exact=int(max_exact_orders), sample_count=int(sample_orders), seed=int(random_seed), waiting_mode=waiting_mode)
if network_type == 'Intercity (Chain)':
    diff_fmax = qa_m2_fmax - qa_m1_fmax
    gain_fmax = qa_m2_adv_fmax - qa_m1_adv_fmax
    diff_fmin = qa_m2_fmin - qa_m1_fmin
    gain_fmin = qa_m2_adv_fmin - qa_m1_adv_fmin
    st.markdown('#### Intercity Network Difference Heatmap using $F_{max}^{avg}$')
    fig_diff_fmax, ax_diff_fmax = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_model_difference_heatmap(ax_diff_fmax, qa_link_distance_values, qa_delta_values, diff_fmax, 'Intercity Network: $\\Delta F_{max}^{avg}=F_{max,\\mathrm{M2}}^{avg}-F_{max,\\mathrm{M1}}^{avg}$')
    st.pyplot(fig_diff_fmax, clear_figure=True)
    st.markdown('#### Intercity Network Quantum Advantage Gain Map using $F_{max}^{avg}$')
    fig_gain_fmax, ax_gain_fmax = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_advantage_gain_map(ax_gain_fmax, qa_link_distance_values, qa_delta_values, gain_fmax, 'Intercity Network: Model 2 advantage gain using $F_{max}^{avg}$')
    st.pyplot(fig_gain_fmax, clear_figure=True)
    st.markdown('#### Intercity Network Difference Heatmap using $F_{min}^{avg}$')
    fig_diff_fmin, ax_diff_fmin = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_model_difference_heatmap(ax_diff_fmin, qa_link_distance_values, qa_delta_values, diff_fmin, 'Intercity Network: $\\Delta F_{min}^{avg}=F_{min,\\mathrm{M2}}^{avg}-F_{min,\\mathrm{M1}}^{avg}$')
    st.pyplot(fig_diff_fmin, clear_figure=True)
    st.markdown('#### Intercity Network Quantum Advantage Gain Map using $F_{min}^{avg}$')
    fig_gain_fmin, ax_gain_fmin = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_advantage_gain_map(ax_gain_fmin, qa_link_distance_values, qa_delta_values, gain_fmin, 'Intercity Network: Model 2 advantage gain using $F_{min}^{avg}$')
    st.pyplot(fig_gain_fmin, clear_figure=True)
    df_diff_fmax = pd.DataFrame(diff_fmax, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    df_diff_fmin = pd.DataFrame(diff_fmin, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    df_gain_fmax = pd.DataFrame(gain_fmax, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    df_gain_fmin = pd.DataFrame(gain_fmin, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    st.download_button('Download Intercity Network Model2-minus-Model1 Fmax Difference Grid (CSV)', df_diff_fmax.to_csv(index=True).encode('utf-8'), 'chain_model2_minus_model1_fmax_grid.csv', 'text/csv')
    st.download_button('Download Intercity Network Model2-minus-Model1 Fmin Difference Grid (CSV)', df_diff_fmin.to_csv(index=True).encode('utf-8'), 'chain_model2_minus_model1_fmin_grid.csv', 'text/csv')
    st.download_button('Download Intercity Network Model2 Advantage Gain Fmax Map (CSV)', df_gain_fmax.to_csv(index=True).encode('utf-8'), 'chain_model2_advantage_gain_fmax_map.csv', 'text/csv')
    st.download_button('Download Intercity Network Model2 Advantage Gain Fmin Map (CSV)', df_gain_fmin.to_csv(index=True).encode('utf-8'), 'chain_model2_advantage_gain_fmin_map.csv', 'text/csv')
else:
    diff_favg = qa_m2_fmax - qa_m1_fmax
    gain_favg = qa_m2_adv_fmax - qa_m1_adv_fmax
    st.markdown('#### Metropolitan Network Difference Heatmap using $F^{avg}$')
    fig_diff_favg, ax_diff_favg = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_model_difference_heatmap(ax_diff_favg, qa_link_distance_values, qa_delta_values, diff_favg, 'Metropolitan Network: $\\Delta F^{avg}=F_{\\mathrm{M2}}^{avg}-F_{\\mathrm{M1}}^{avg}$')
    st.pyplot(fig_diff_favg, clear_figure=True)
    st.markdown('#### Metropolitan Network Quantum Advantage Gain Map using $F^{avg}$')
    fig_gain_favg, ax_gain_favg = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    plot_advantage_gain_map(ax_gain_favg, qa_link_distance_values, qa_delta_values, gain_favg, 'Metropolitan Network: Model 2 advantage gain using $F^{avg}$')
    st.pyplot(fig_gain_favg, clear_figure=True)
    df_diff_favg = pd.DataFrame(diff_favg, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    df_gain_favg = pd.DataFrame(gain_favg, index=np.round(qa_delta_values, 4), columns=np.round(qa_link_distance_values, 4))
    st.download_button('Download Metropolitan Network Model2-minus-Model1 Difference Grid (CSV)', df_diff_favg.to_csv(index=True).encode('utf-8'), 'star_model2_minus_model1_grid.csv', 'text/csv')
    st.download_button('Download Metropolitan Network Model2 Advantage Gain Map (CSV)', df_gain_favg.to_csv(index=True).encode('utf-8'), 'star_model2_advantage_gain_map.csv', 'text/csv')
if network_type == 'Intracity (Star)':
    st.subheader('Metropolitan Network Average Fidelity vs Δt — Multiple Node Counts')
    multi_node_results = multi_node_delta_sweep_cached(tuple(multi_node_values), tuple(map(float, delta_values)), m, total_distance, METROPOLITAN_LINK_DISTANCE_KM, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, model_type, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    fig_multi, ax_multi = plt.subplots(figsize=PHYSREV_TALL_FIGSIZE, constrained_layout=True)
    for i, n in enumerate(multi_node_values):
        ax_multi.plot(delta_values, multi_node_results[n], marker='o', markersize=3, color=PHYSREV_COLORS[i % len(PHYSREV_COLORS)], label=f'{n} nodes (L={METROPOLITAN_LINK_DISTANCE_KM:.1f} km/link)')
    ax_multi.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_multi.set_ylabel('Average Fidelity')
    ax_multi.set_title(f'Metropolitan Network, $L={METROPOLITAN_LINK_DISTANCE_KM:.1f}\\,\\mathrm{{km/link}}$')
    physrev_legend(ax_multi, ncol=2)
    apply_normal_axis_format(ax_multi)
    st.pyplot(fig_multi, clear_figure=True)
    df_multi = pd.DataFrame({'Delta_t_unit_ms': delta_values})
    for n in multi_node_values:
        df_multi[f'Metropolitan_Network_{n}_nodes'] = multi_node_results[n]
    st.dataframe(df_multi, use_container_width=True)
    st.download_button('Download Multi-Node Metropolitan Network Data (CSV)', df_multi.to_csv(index=False).encode('utf-8'), 'metropolitan_network_multi_node.csv', 'text/csv')
if model_type in ['Model 1', 'Model 2']:
    topology_name_cd = 'chain' if network_type == 'Intercity (Chain)' else 'star'
    topology_label_cd = 'Intercity Network' if topology_name_cd == 'chain' else 'Metropolitan Network'
    st.subheader(f'{model_type} — Critical Distance vs Modes (Fixed 5-Node {topology_label_cd})')
    st.caption('Critical distance is defined as the maximum total distance up to which the elementary-link term remains at least 0.99 in a fixed 5-node network. For the Metropolitan Network case, the path-dependent curves correspond to 1-hop and 2-hop paths.')
    critical_threshold = 0.99
    fixed_total_distances = np.linspace(50, 1000, 1200)
    anchor_modes_critical = [10, 50, 100, 500, 1000, 2000, 5000, 10000]
    mode_values_critical = sorted(set(np.round(np.logspace(0, 4, 180)).astype(int).tolist() + anchor_modes_critical))
    critical_results = critical_distance_vs_modes(topology_name=topology_name_cd, model_name=model_type, mode_values_critical=mode_values_critical, total_distance_values=fixed_total_distances, alpha_value=alpha, eta_d1_value=eta_d1, rho_value=rho, n_nodes_fixed=5, threshold=critical_threshold)

    def _critical_label(exp):
        if topology_name_cd == 'chain':
            if model_type == 'Model 1':
                return 'Model 1: $p_{\\rm elem}^{4}\\geq0.99$'
            return f'Model 2: $p_{{\\rm elem}}^{{{exp}}}\\geq0.99$'
        if model_type == 'Model 1':
            return 'Model 1: $p_{\\rm elem}^{2}\\geq0.99$'
        return f'Model 2: $p_{{\\rm elem}}^{{{exp}}}\\geq0.99$'
    color_map = {1: PHYSREV_COLORS[2], 2: PHYSREV_COLORS[0], 3: '#f28e2b', 4: '#e15759'}
    if model_type == 'Model 1':
        color_map = {exp: PHYSREV_COLORS[2] for exp in color_map}
    linestyle_map = {1: '--', 2: '-', 3: ':', 4: '-.'}
    fig_chain_elem, ax_chain_elem = plt.subplots(figsize=PHYSREV_FIGSIZE, constrained_layout=True)
    critical_anchor_rows = []
    for exp, vals in critical_results.items():
        y_vals = np.array(vals, dtype=float)
        ax_chain_elem.plot(mode_values_critical, y_vals, color=color_map.get(exp, PHYSREV_NEUTRAL_DARK), linestyle=linestyle_map.get(exp, '-'), linewidth=1.55, marker='o', markersize=2.6, markevery=12, markerfacecolor='white', markeredgecolor=color_map.get(exp, PHYSREV_NEUTRAL_DARK), markeredgewidth=0.75, label=_critical_label(exp))
        anchor_x = [mm for mm in anchor_modes_critical if mm in mode_values_critical]
        if anchor_x:
            anchor_idx = [mode_values_critical.index(mm) for mm in anchor_x]
            anchor_y = y_vals[anchor_idx]
            curve_label = _critical_label(exp)
            ax_chain_elem.plot(anchor_x, anchor_y, linestyle='none', marker='D', markersize=7.0, color=color_map.get(exp, PHYSREV_NEUTRAL_DARK), markerfacecolor=color_map.get(exp, PHYSREV_NEUTRAL_DARK), markeredgecolor='white', markeredgewidth=0.9, zorder=7)
            for x_val, y_val in zip(anchor_x, anchor_y):
                if np.isnan(y_val):
                    critical_anchor_rows.append({'Modes_m': x_val, 'Curve': curve_label, 'Critical_Distance_km': np.nan})
                    continue
                ax_chain_elem.axvline(x_val, color=color_map.get(exp, PHYSREV_NEUTRAL_DARK), linewidth=0.45, alpha=0.18, zorder=1)
                ax_chain_elem.annotate(f'{y_val:.0f}', xy=(x_val, y_val), xytext=(0, 8), textcoords='offset points', ha='center', va='bottom', fontsize=7.2, color=color_map.get(exp, PHYSREV_NEUTRAL_DARK), bbox=dict(boxstyle='round,pad=0.16', fc='white', ec='none', alpha=0.72), zorder=8)
                critical_anchor_rows.append({'Modes_m': x_val, 'Curve': curve_label, 'Critical_Distance_km': round(float(y_val), 3)})
    ax_chain_elem.set_xscale('log')
    ax_chain_elem.set_xlabel('Multiplexing modes, $m$')
    ax_chain_elem.set_ylabel('Critical total distance (km)')
    ax_chain_elem.set_title(f'{model_type}: fixed 5-node {topology_label_cd.lower()}')
    ax_chain_elem.set_facecolor('white')
    fig_chain_elem.patch.set_facecolor('white')
    ax_chain_elem.set_xlim(min(mode_values_critical), max(mode_values_critical))
    ax_chain_elem.set_xticks(anchor_modes_critical)
    ax_chain_elem.set_xticklabels([str(v) for v in anchor_modes_critical])
    ax_chain_elem.xaxis.set_minor_formatter(mticker.NullFormatter())
    ax_chain_elem.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.0f'))
    ax_chain_elem.tick_params(which='both', direction='in', top=True, right=True)
    ax_chain_elem.grid(True, which='major')
    ax_chain_elem.grid(True, which='minor', linewidth=0.25, alpha=0.16)
    physrev_legend(ax_chain_elem, loc='best')
    st.pyplot(fig_chain_elem, clear_figure=True)
    df_chain_elem = pd.DataFrame({'Modes_m': mode_values_critical})
    for exp, vals in critical_results.items():
        df_chain_elem[f'Critical_Total_Distance_km_pelem_pow_{exp}'] = vals
    if critical_anchor_rows:
        st.markdown('**Marked critical-distance points**')
        df_anchor_critical = pd.DataFrame(critical_anchor_rows)
        st.dataframe(df_anchor_critical, use_container_width=True)
        st.download_button(f'Download {model_type} Marked Critical Points (CSV)', df_anchor_critical.to_csv(index=False).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_{topology_name_cd}_marked_critical_points.csv", 'text/csv')
    st.dataframe(df_chain_elem, use_container_width=True)
    st.download_button(f'Download {model_type} Critical Distance Data (CSV)', df_chain_elem.to_csv(index=False).encode('utf-8'), f"{model_type.lower().replace(' ', '_')}_{topology_name_cd}_critical_distance_vs_modes.csv", 'text/csv')
st.subheader('Model 0 vs Model 1 vs Model 2 — Average Fidelity vs Δt')
st.caption(f'Using m = {int(m_comparison)} (set in sidebar under Model Comparison Settings)')
if network_type == 'Intercity (Chain)':
    m0_best, m0_worst, m1_best, m1_worst, m2_best, m2_worst = model_comparison_delta_sweep_cached('chain', tuple(map(float, delta_values)), n_nodes, int(m_comparison), distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    df_cmp_models = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'M0_Intercity_Network_Fmax': m0_best, 'M0_Intercity_Network_Fmin': m0_worst, 'M1_Intercity_Network_Fmax': m1_best, 'M1_Intercity_Network_Fmin': m1_worst, 'M2_Intercity_Network_Fmax': m2_best, 'M2_Intercity_Network_Fmin': m2_worst})
    df_cmp_models['Diff_Fmax_M2_minus_M1'] = df_cmp_models['M2_Intercity_Network_Fmax'] - df_cmp_models['M1_Intercity_Network_Fmax']
    df_cmp_models['Diff_Fmin_M2_minus_M1'] = df_cmp_models['M2_Intercity_Network_Fmin'] - df_cmp_models['M1_Intercity_Network_Fmin']
    fig_cmp_models, (ax_cmp_full, ax_cmp_zoom) = plt.subplots(2, 1, figsize=PHYSREV_PANEL_FIGSIZE, sharex=True, constrained_layout=True)
    ax_cmp_full.plot(delta_values, m0_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Model 0, $F_{\\max}^{\\rm avg}$')
    ax_cmp_full.plot(delta_values, m0_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Model 0, $F_{\\min}^{\\rm avg}$')
    ax_cmp_full.plot(delta_values, m1_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Model 1, $F_{\\max}^{\\rm avg}$')
    ax_cmp_full.plot(delta_values, m1_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Model 1, $F_{\\min}^{\\rm avg}$')
    ax_cmp_full.plot(delta_values, m2_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Model 2, $F_{\\max}^{\\rm avg}$')
    ax_cmp_full.plot(delta_values, m2_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Model 2, $F_{\\min}^{\\rm avg}$')
    ax_cmp_full.set_title(f'Intercity Network, $m={int(m_comparison)}$')
    ax_cmp_full.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp_full, ncol=2)
    full_vals = list(m0_best) + list(m0_worst) + list(m1_best) + list(m1_worst) + list(m2_best) + list(m2_worst)
    full_y_min = min(full_vals)
    full_y_max = max(full_vals)
    full_margin = (full_y_max - full_y_min) * 0.08 if full_y_max > full_y_min else 0.01
    ax_cmp_full.set_ylim(full_y_min - full_margin, full_y_max + full_margin)
    apply_normal_axis_format(ax_cmp_full)
    ax_cmp_zoom.plot(delta_values, m1_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Model 1, $F_{\\max}^{\\rm avg}$')
    ax_cmp_zoom.plot(delta_values, m1_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Model 1, $F_{\\min}^{\\rm avg}$')
    ax_cmp_zoom.plot(delta_values, m2_best, color=COLOR_CHAIN_MAX, linestyle='-', label='Model 2, $F_{\\max}^{\\rm avg}$')
    ax_cmp_zoom.plot(delta_values, m2_worst, color=COLOR_CHAIN_MIN, linestyle='--', label='Model 2, $F_{\\min}^{\\rm avg}$')
    ax_cmp_zoom.fill_between(delta_values, m1_best, m2_best, alpha=0.2)
    ax_cmp_zoom.fill_between(delta_values, m1_worst, m2_worst, alpha=0.2)

    def annotate_point(ax, x, y, text, x_offset=8, y_offset=8):
        ax.annotate(f'{text:.4f}', xy=(x, y), xytext=(x_offset, y_offset), textcoords='offset points', fontsize=9, bbox=dict(boxstyle='round,pad=0.2', fc='white', alpha=0.8))
    start_x = delta_values[0]
    end_x = delta_values[-1]
    annotate_point(ax_cmp_zoom, start_x, m1_best[0], m1_best[0], 8, 8)
    annotate_point(ax_cmp_zoom, end_x, m1_best[-1], m1_best[-1], -40, 8)
    annotate_point(ax_cmp_zoom, start_x, m1_worst[0], m1_worst[0], 8, -12)
    annotate_point(ax_cmp_zoom, end_x, m1_worst[-1], m1_worst[-1], -40, -12)
    annotate_point(ax_cmp_zoom, start_x, m2_best[0], m2_best[0], 8, 20)
    annotate_point(ax_cmp_zoom, end_x, m2_best[-1], m2_best[-1], -40, 20)
    annotate_point(ax_cmp_zoom, start_x, m2_worst[0], m2_worst[0], 8, -25)
    annotate_point(ax_cmp_zoom, end_x, m2_worst[-1], m2_worst[-1], -40, -25)
    zoom_vals = list(m1_best) + list(m1_worst) + list(m2_best) + list(m2_worst)
    zoom_y_min = min(zoom_vals)
    zoom_y_max = max(zoom_vals)
    zoom_margin = max((zoom_y_max - zoom_y_min) * 0.25, 0.002)
    ax_cmp_zoom.set_ylim(zoom_y_min - zoom_margin, zoom_y_max + zoom_margin)
    ax_cmp_zoom.set_title('Zoomed comparison')
    ax_cmp_zoom.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_cmp_zoom.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp_zoom, ncol=2)
    apply_normal_axis_format(ax_cmp_zoom)
    st.pyplot(fig_cmp_models, clear_figure=True)
    c1, c2 = st.columns(2)
    c1.metric('Max Fmax Difference (M2 - M1)', f"{df_cmp_models['Diff_Fmax_M2_minus_M1'].max():.6f}")
    c2.metric('Max Fmin Difference (M2 - M1)', f"{df_cmp_models['Diff_Fmin_M2_minus_M1'].max():.6f}")
else:
    m0_best, m0_worst, m1_best, m1_worst, m2_best, m2_worst = model_comparison_delta_sweep_cached('star', tuple(map(float, delta_values)), n_nodes, int(m_comparison), distance_per_link, T, alpha, eta_d1, eta_d2, rho, eta_mem, fiber_index, int(max_exact_orders), int(sample_orders), int(random_seed), waiting_mode=waiting_mode)
    df_cmp_models = pd.DataFrame({'Delta_t_unit_ms': delta_values, 'M0_Metropolitan_Network': m0_best, 'M1_Metropolitan_Network': m1_best, 'M2_Metropolitan_Network': m2_best})
    df_cmp_models['Diff_M2_minus_M1'] = df_cmp_models['M2_Metropolitan_Network'] - df_cmp_models['M1_Metropolitan_Network']
    fig_cmp_models, (ax_cmp_full, ax_cmp_zoom) = plt.subplots(2, 1, figsize=PHYSREV_PANEL_FIGSIZE, sharex=True, constrained_layout=True)
    ax_cmp_full.plot(delta_values, m0_best, color=COLOR_MODEL_0, linestyle='-', label='Model 0')
    ax_cmp_full.plot(delta_values, m1_best, color=PHYSREV_COLORS[1], linestyle='-', label='Model 1')
    ax_cmp_full.plot(delta_values, m2_best, color=PHYSREV_COLORS[3], linestyle='-', label='Model 2')
    ax_cmp_full.set_title(f'Metropolitan Network, $m={int(m_comparison)}$')
    ax_cmp_full.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp_full)
    full_vals = list(m0_best) + list(m1_best) + list(m2_best)
    full_y_min = min(full_vals)
    full_y_max = max(full_vals)
    full_margin = (full_y_max - full_y_min) * 0.08 if full_y_max > full_y_min else 0.01
    ax_cmp_full.set_ylim(full_y_min - full_margin, full_y_max + full_margin)
    apply_normal_axis_format(ax_cmp_full)
    ax_cmp_zoom.plot(delta_values, m1_best, color=PHYSREV_COLORS[1], linestyle='-', label='Model 1')
    ax_cmp_zoom.plot(delta_values, m2_best, color=PHYSREV_COLORS[3], linestyle='-', label='Model 2')
    ax_cmp_zoom.fill_between(delta_values, m1_best, m2_best, alpha=0.2)

    def annotate_point_star(ax, x, y, text, x_offset=8, y_offset=8):
        ax.annotate(f'{text:.4f}', xy=(x, y), xytext=(x_offset, y_offset), textcoords='offset points', fontsize=9, bbox=dict(boxstyle='round,pad=0.2', fc='white', alpha=0.8))
    start_x = delta_values[0]
    end_x = delta_values[-1]
    annotate_point_star(ax_cmp_zoom, start_x, m1_best[0], m1_best[0], 8, 8)
    annotate_point_star(ax_cmp_zoom, end_x, m1_best[-1], m1_best[-1], -40, 8)
    annotate_point_star(ax_cmp_zoom, start_x, m2_best[0], m2_best[0], 8, 20)
    annotate_point_star(ax_cmp_zoom, end_x, m2_best[-1], m2_best[-1], -40, 20)
    zoom_vals = list(m1_best) + list(m2_best)
    zoom_y_min = min(zoom_vals)
    zoom_y_max = max(zoom_vals)
    zoom_margin = max((zoom_y_max - zoom_y_min) * 0.25, 0.002)
    ax_cmp_zoom.set_ylim(zoom_y_min - zoom_margin, zoom_y_max + zoom_margin)
    ax_cmp_zoom.set_title('Zoomed comparison')
    ax_cmp_zoom.set_xlabel('Waiting interval, $\\Delta t$ (ms)')
    ax_cmp_zoom.set_ylabel('Average Fidelity')
    physrev_legend(ax_cmp_zoom)
    apply_normal_axis_format(ax_cmp_zoom)
    st.pyplot(fig_cmp_models, clear_figure=True)
    st.metric('Max Difference (M2 - M1)', f"{df_cmp_models['Diff_M2_minus_M1'].max():.6f}")
st.dataframe(df_cmp_models, use_container_width=True)
st.download_button('Download Model Comparison Data (CSV)', df_cmp_models.to_csv(index=False).encode('utf-8'), 'model_comparison.csv', 'text/csv')
st.subheader('Δt Sweep Debug Table')
st.dataframe(df_delta, use_container_width=True)
st.subheader('Excel Export')
if network_type == 'Intercity (Chain)':
    excel_bytes = make_excel_bytes({'summary': pd.DataFrame({'Metric': ['Intercity Network Fmax', 'Intercity Network Fmin', 't0_ms'], 'Value': [chain_fmax, chain_fmin, t0]}), 'modes': df_modes, 'delta': df_delta, 'chain_fmax': chain_df_max.drop(columns=['raw_path_nodes']), 'chain_fmin': chain_df_min.drop(columns=['raw_path_nodes'])})
else:
    excel_bytes = make_excel_bytes({'summary': pd.DataFrame({'Metric': ['Metropolitan Network Fidelity', 't0_ms'], 'Value': [star_avg, t0]}), 'modes': df_modes, 'delta': df_delta, 'star': star_df.drop(columns=['raw_path_nodes'])})
if excel_bytes is not None:
    st.download_button('Download Excel Workbook', excel_bytes, 'quantum_network_results.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
else:
    st.info('Excel export not available because openpyxl is not installed.')
